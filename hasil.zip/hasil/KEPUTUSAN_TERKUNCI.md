# KEPUTUSAN TERKUNCI

**Dibuat:** 2026-10-27, 10:08:33 WIB
**Status:** dikunci sebelum Tahap 1 dijalankan. File ini tidak boleh diubah setelah
Tahap 1 dimulai.

Isi di bawah adalah salinan apa adanya dari bagian 3 dan 4 brief eksperimen
(brief bertanggal 27 Oktober 2026).

---

## 3. Desain yang dikunci

| Komponen | Nilai |
|---|---|
| Periode data | 2026-10-14 00:00 s.d. 2026-10-20 23:59 UTC (satu minggu) |
| Dataset | `candle_1m`, `ticker_5m` |
| Definisi harga | candle `typical` = (high+low+close)/3, ticker `mid` = (bid+ask)/2 |
| Horizon (menit) | 1, 5, 15, 30, 60 (horizon 1 hanya untuk candle) |
| Model | XGBoost, LightGBM, CatBoost, AdaBoost, + Naive sebagai pembanding |
| Target | Log return h menit ke depan, dikonversi ke rupiah |
| Fitur | Sesuai `btcpred/data.py` (42 fitur candle, 32 fitur ticker) |
| Tuning | `N_TRIALS` 30, `N_FOLDS` 5, walk-forward CV di data latih, objektif MAE return |
| Seed | 42 |
| Metrik utama | MAE vs Naive (%) |
| Metrik pendukung | RMSE vs Naive (%), MAPE, akurasi arah, uji Diebold-Mariano (p_MAE, p_RMSE) |

Catatan: status data (satu minggu vs seluruh data sampai Februari 2027, ±40.000
baris) belum dipastikan ke dosen. Tandai semua hasil ini sebagai **"eksperimen data
satu minggu (14–20 Okt 2026)"**.

---

## 4. Tahapan dan aturan pemilihan

Definisi yang dipakai di semua tahap:
- **Signifikan lebih baik dari Naive** = `MAE_vs_naive_pct < 0` **dan** `DM_MAE < 0`
  **dan** `p_MAE < 0.05`.
- **Skor pasangan** (dataset, horizon) = nilai `MAE_vs_naive_pct` terkecil di antara
  keempat model pada pasangan itu.

### Tahap 1: mencari time frame

```bash
python run.py --optimizers tpe --splits 0.8 --tag tahap1
python ringkas.py --tag tahap1 > hasil/laporan/tahap1_ringkasan.txt
```

**Aturan memilih pasangan (dataset, horizon) untuk tahap 2:**

1. Kalau ada model yang signifikan lebih baik dari Naive: pilih pasangan dengan skor
   terkecil di antara pasangan yang punya model signifikan.
2. Kalau tidak ada sama sekali: pilih pasangan dengan skor terkecil, dan tulis jelas
   di laporan **"tidak ada model yang signifikan lebih baik dari Naive"**.
3. Kalau seri: pilih horizon yang lebih pendek, lalu dataset `candle_1m`.

Lalu **berhenti** dan kirim laporan ke Ferdi.

### Tahap 2: membandingkan metode optimasi

Hanya pada pasangan terpilih dari tahap 1.

```bash
python run.py --datasets <DATASET> --horizons <H> --splits 0.8 \
  --optimizers default grid random tpe cmaes ga qmc --tag tahap2
python ringkas.py --tag tahap2 > hasil/laporan/tahap2_ringkasan.txt
```

**Aturan memilih metode optimasi untuk tahap 3 dan 4:** rata-rata
`MAE_vs_naive_pct` keempat model paling kecil. Kalau seri, pilih yang waktu tuning
totalnya paling singkat. `default` tidak boleh dipilih (fungsinya sebagai pembanding
tanpa tuning).

**Berhenti** dan kirim laporan.

### Tahap 3: uji rasio pembagian data

```bash
python run.py --datasets <DATASET> --horizons <H> --optimizers <METODE> \
  --splits 0.8 0.7 0.6 --tag tahap3
python ringkas.py --tag tahap3 > hasil/laporan/tahap3_ringkasan.txt
```

**Tidak ada pemilihan.** Laporkan ketiga rasio apa adanya. Ingat, MAE rupiah
antar-rasio tidak bisa dibandingkan langsung karena periode ujinya berbeda. Yang
dibandingkan hanya `MAE_vs_naive_pct` di dalam rasio yang sama.

**Berhenti** dan kirim laporan.

### Tahap 4: teknik optimasi tambahan

Jalankan **satu per satu** (setiap teknik diuji terpisah), semua pada pasangan dan
metode terpilih, split 0.8:

```bash
python run.py --datasets <DATASET> --horizons <H> --optimizers <METODE> --splits 0.8 --early-stop --tag tahap4_earlystop
python run.py --datasets <DATASET> --horizons <H> --optimizers <METODE> --splits 0.8 --top-k 15 --tag tahap4_topk15
python run.py --datasets <DATASET> --horizons <H> --optimizers <METODE> --splits 0.8 --loss l1 --tag tahap4_lossl1
python run.py --datasets <DATASET> --horizons <H> --optimizers <METODE> --splits 0.8 --pruner median --tag tahap4_prunermedian
```

Ringkas masing-masing tag ke `hasil/laporan/tahap4_<nama>_ringkasan.txt`. Pembanding
tiap teknik adalah hasil tahap 2 untuk metode yang sama. **Tidak ada pemilihan**,
cukup laporkan selisihnya.

**Berhenti** dan kirim laporan.
