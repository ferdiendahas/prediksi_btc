# LOG PERUBAHAN

Catatan semua perubahan kode dan environment. Perubahan di bawah dilakukan
**sebelum** brief eksperimen diterima dan **sebelum** Tahap 1 dijalankan.

---

## 2026-10-27 — Environment

**Masalah:** belum ada virtual environment; `python3` global (Homebrew 3.14) tidak
memiliki pandas/numpy/xgboost/lightgbm/catboost/optuna.

**Percobaan pertama (gagal):** membuat venv dengan Homebrew `python@3.12`.
Instalasi Python 3.12 di mesin ini rusak — modul `pyexpat` tertaut ke libexpat
yang sudah berubah versi:

```
Symbol not found: _XML_SetAllocTrackerActivationThreshold
Referenced from: .../pyexpat.cpython-312-darwin.so
Expected in:     /usr/lib/libexpat.1.dylib
```

Akibatnya `plistlib` ikut gagal diimpor, `ensurepip` gagal, dan venv tidak dapat
dibuat. Perbaikan bila suatu saat Python 3.12 dibutuhkan: `brew reinstall python@3.12`.

**Tindakan:** venv dibuat dengan Homebrew `python3.14` (sehat).

```bash
/opt/homebrew/bin/python3.14 -m venv .venv
.venv/bin/pip install -r requirements.txt
```

Versi paket persis tercatat di `hasil/metadata/versi_paket.txt`.
LightGBM berjalan tanpa perlu `brew install libomp`.

**Tidak ada perubahan pada `requirements.txt`.**

---

## 2026-10-27 — `run.py`: `--tag` dimasukkan ke `run_id` dan id baris Naive

**Masalah (bug):** `run_id` tidak memuat `tag`. Run dengan konfigurasi sama tetapi
`--tag` berbeda dianggap sudah pernah selesai, lalu dilewati tanpa dicatat.

**Dampak pada alur bertahap README:** Tahap 1 (`--optimizers tpe --splits 0.8
--tag tahap1`) dan Tahap 2 (`--optimizers default grid random tpe cmaes ga
--splits 0.8 --tag tahap2`) beririsan pada metode `tpe`. Baris `tpe` di Tahap 2
tidak tercatat, sehingga `ringkas.py --tag tahap2` hanya menampilkan 5 dari 6
metode optimasi dan TPE tidak ikut dibandingkan.

**Verifikasi bug:** menjalankan ulang konfigurasi yang sudah ada dengan tag baru
menghasilkan 0 baris baru di `hasil_semua.csv`.

**Perubahan:** `tag` ditambahkan ke akhir string `rid` (baris run model) dan `nid`
(baris Naive) di `run.py`.

**Verifikasi sesudah perbaikan:** konfigurasi sama dengan tag berbeda kini tercatat
(2 baris: Naive + model); logika lewati-run untuk tag yang sama tetap berfungsi.
Angka hasil identik pada run ulang (MAE Rp636.226 pada uji smoke), jadi perbaikan
ini tidak mengubah nilai metrik, hanya menambah waktu komputasi untuk konfigurasi
yang beririsan antar tahap.

---

## 2026-10-27 — `btcpred/optim.py`: fallback bila semua trial Optuna gagal/dipangkas

**Masalah:** bila tidak ada satu pun trial berstatus `COMPLETE` (mungkin terjadi
dengan `--pruner median` pada data pendek), `study.best_trial` melempar exception
dan menggugurkan seluruh proses `run.py` yang sedang berjalan.

**Perubahan:** sebelum mengakses `study.best_trial`, dicek apakah ada trial
`COMPLETE`. Bila tidak ada, dipakai `M.DEFAULT[name]` dan run tetap tercatat
(kolom `n_trials` dan `n_pruned` tetap mencatat apa yang terjadi).

**Catatan:** jalur fallback ini tidak aktif pada pengujian yang sudah dilakukan;
sifatnya pengaman agar run panjang tidak gugur total.

---

## 2026-10-27 — Dokumentasi

- `README.md` bagian "Mengulang dari awal": ditambah penjelasan bahwa `--tag` ikut
  menentukan apakah sebuah run dilewati.
- Docstring `run.py`: penjelasan yang sama.

Tidak ada perubahan pada `config.py`, definisi fitur (`btcpred/data.py`), ruang
hyperparameter (`btcpred/models.py`), metrik maupun uji statistik
(`btcpred/evaluate.py`).

---

## Pengujian sebelum eksperimen (smoke test)

Dijalankan 2026-10-27 dengan `--trials 3..6 --folds 3` pada periode default, untuk
memastikan tidak ada error di semua jalur kode: 4 model x 7 metode optimasi, kedua
dataset, horizon 1/5/15/60, split 0,6/0,7/0,8, serta `--early-stop`, `--top-k`,
`--loss l1`, `--pruner median`, `--pruner hyperband`, logika lewati-run, dan
`ringkas.py`. Tidak ditemukan error lain.

Seluruh keluaran smoke test **tidak** disimpan di `hasil/` (dipindahkan ke folder
sementara di luar proyek), sehingga `hasil/hasil_semua.csv` pada Tahap 1 dimulai
dari kosong.

---

## Perubahan setelah Tahap 1 dimulai

## 2026-11-11 — Tahap 1 diulang dengan data terbaru (tag `p2_tahap1`)

**Permintaan:** menjalankan ulang Tahap 1 memakai data hasil pengumpulan terbaru
(`data/btcidr_candle_1menit_20261110_1642.csv`, `data/btcidr_ticker_5menit_20261110_1642.csv`,
diekspor 2026-11-10 16:42 WIB).

**Cakupan data baru:** 2026-10-09 06:28 s.d. 2026-11-10 16:40 UTC.
Candle 1 menit 46.693 bar, ticker 5 menit 9.338 bar. Diperiksa: tidak ada bar yang
hilang (jumlah bar aktual = jumlah bar yang diharapkan, tidak ada jeda > 2 bar).

**Perubahan `config.py`:** hanya `DATA[...]["path"]` diarahkan ke dua file baru di
atas. `START_UTC`/`END_UTC` di config TIDAK diubah (tetap 14-20 Okt 2026); periode
baru diberikan lewat argumen `--start`/`--end` saja. Tidak ada perubahan pada
fitur, ruang hyperparameter, metrik, maupun uji statistik.

**Perintah yang dijalankan:**

```bash
python run.py --optimizers tpe --splits 0.8 \
  --start "2026-10-10 00:00" --end "2026-11-10 16:00" --tag p2_tahap1
```

Periode dipotong di 2026-10-10 00:00 supaya mulai dari batas hari penuh (hari
pertama data hanya terisi sebagian sejak 06:28), dan berakhir 16:00 sebagai batas
jam bulat terakhir yang tersedia. Total ±31,7 hari.

**Kenapa tag baru, bukan `tahap1`:** `hasil/KEPUTUSAN_TERKUNCI.md` mengunci periode
Tahap 1 pada 14-20 Okt 2026 dan tidak boleh diubah. Hasil ini dicatat sebagai
eksperimen terpisah dengan tag `p2_tahap1`, sehingga 45 baris `tahap1` yang
lama tetap utuh dan kedua periode bisa dibandingkan berdampingan. Keputusan apakah
Tahap 2-4 ikut diulang di periode baru ada di tangan Ferdi.


---

## 2026-11-11 — Penamaan ulang hasil data baru menjadi Percobaan 2 (`p2_`)

Semua hasil data terbaru diberi nama `p2_` (percobaan kedua), supaya terpisah jelas
dari percobaan pertama (data 1 minggu, tag `tahap1`..`tahap4_*`).

| Dari | Menjadi |
|---|---|
| tag `tahap1_databaru` (45 baris) | tag `p2_tahap1` |
| `run_id` berakhiran `\|tahap1_databaru` | `\|p2_tahap1` |
| `hasil/params/*tahap1_databaru.json` (36 file) | `*p2_tahap1.json` |
| `hasil/prediksi/*tahap1_databaru.csv` (36 file) | `*p2_tahap1.csv` |
| `hasil/laporan/LAPORAN_TAHAP1_DATABARU.md` | `hasil/laporan/LAPORAN_P2_TAHAP1.md` |
| `hasil/laporan/tahap1_databaru_*.txt` | `hasil/laporan/p2_tahap1_*.txt` |

`run_id` ikut diubah supaya tetap cocok dengan nama file dan logika lewati-run
`run.py` tidak menjalankan ulang run yang sudah selesai. Keunikan `run_id` sudah
diverifikasi setelah perubahan. Nilai metrik tidak disentuh. Cadangan
`hasil_semua.csv` sebelum perubahan disimpan di luar proyek.

**Temuan sampingan:** `ringkas.py` selalu menulis empat tabel CSV ke root
`hasil/ringkasan/`, tidak ke subfolder per tag — subfolder `tahap1/`..`tahap4_*/`
ternyata hasil pemindahan manual di sesi sebelumnya. Akibatnya `ringkas.py --tag
p2_tahap1` menimpa keempat CSV di root. Tabel versi p2 dipindahkan ke
`hasil/ringkasan/p2_tahap1/`, lalu root dibuat ulang dengan `python ringkas.py`
tanpa filter (berisi gabungan semua run, sama seperti fungsi aslinya). Tidak ada
hasil yang hilang: keempat CSV itu seluruhnya turunan dari `hasil_semua.csv`.

---

## 2026-11-11 — Tahap 3 P2 dijalankan dengan DUA metode optimasi

**Penyimpangan dari `KEPUTUSAN_TERKUNCI.md`.** Aturan terkunci menetapkan Tahap 3
memakai satu metode terpilih dari Tahap 2 (`cmaes`). Atas permintaan Ferdi,
Tahap 3 dijalankan untuk `cmaes` **dan** `tpe` sekaligus agar hasilnya lebih kaya.

```bash
python run.py --datasets ticker_5m --horizons 60 --splits 0.8 0.7 0.6 \
  --optimizers cmaes tpe --start "2026-10-10 00:00" --end "2026-11-10 16:00" \
  --tag p2_tahap3
```

24 run model + 3 baris Naive, 8,3 menit, semua selesai. `cmaes` tetap metode resmi
hasil Tahap 2; `tpe` berstatus pembanding tambahan. Tidak ada perubahan kode,
fitur, ruang hyperparameter, metrik, maupun uji statistik.

---

## 2026-11-11 — `ringkas.py`: tabel baru `sebaran_prediksi` (uji model datar)

**Masalah yang ditemukan di Tahap 3 P2.** Model pohon bisa dituning sampai praktis
berhenti memprediksi: ia mengeluarkan satu konstanta untuk semua baris uji. Di tabel
MAE hasilnya tampak "menang tipis dari Naive", padahal kandungan informasinya nol —
yang terjadi hanya Naive digeser sebesar konstanta itu. Contoh: XGBoost `ticker_5m`
h60 split 60:40 mengeluarkan satu nilai identik untuk seluruh 3.644 baris uji, dan
tercatat −0,006% terhadap Naive.

Kolom `std_pred_return` sudah ada di `hasil_semua.csv` sejak awal tetapi tidak pernah
ditampilkan di ringkasan mana pun, sehingga kondisi ini tidak terlihat di Percobaan 1.

**Perubahan:** fungsi `sebaran()` ditambahkan ke `ringkas.py`, dipanggil sebagai tabel
ke-4 (sebelum tabel peringkat). Ia membaca file prediksi tiap run dan menghitung:

| kolom | arti |
|---|---|
| `n_unik` | banyaknya nilai prediksi berbeda di seluruh data uji (1 = datar) |
| `rasio_sebaran` | std(return prediksi) / std(return aktual); ~0 = datar |
| `geser_rata2` | rata-rata return prediksi (mendeteksi keunggulan dari tren, bukan prediksi) |
| `status` | `DATAR` bila `n_unik <= 3` atau `rasio_sebaran < 0,01` |

Ambang 0,01 bersifat penanda untuk memicu pemeriksaan, bukan batas kebenaran; angka
mentahnya tetap ditampilkan. Kolom `std_pred_return` juga ditambahkan ke tabel
peringkat. Tersimpan ke `hasil/ringkasan/sebaran_prediksi.csv`.

**Tidak ada metrik yang berubah** — fungsi ini hanya membaca dan merangkum file
prediksi yang sudah ada. Seluruh ringkasan P2 diregenerasi setelah perubahan.

**Hasil pemeriksaan:** 44 dari 120 run P2 (37%) berstatus DATAR. Rinciannya per tahap
ada di masing-masing `hasil/laporan/LAPORAN_P2_TAHAP*.md`. Catatan penting untuk
Tahap 1: lima dari tujuh run yang "mengalahkan Naive" ternyata model datar, semuanya
di `candle_1m` h60. Pasangan yang terpilih (`ticker_5m` h60) justru paling sehat —
hanya 1 dari 4 model DATAR dan pemenangnya berstatus `ok`.

---

## 2026-11-11 — Tahap 4 P2 dijalankan dengan dua metode optimasi

Seperti Tahap 3, dijalankan untuk `cmaes` **dan** `tpe` (penyimpangan dari aturan
terkunci, atas permintaan Ferdi). Empat teknik diuji terpisah, masing-masing 8 run:

```bash
python run.py --datasets ticker_5m --horizons 60 --optimizers cmaes tpe --splits 0.8 \
  --start "2026-10-10 00:00" --end "2026-11-10 16:00" <TEKNIK> --tag p2_tahap4_<nama>
# <TEKNIK>: --early-stop | --top-k 15 | --loss l1 | --pruner median
```

32 run, 10,1 menit, semua selesai. Tidak ada perubahan kode selain `ringkas.py` di
atas.

---

## 2026-11-11 — Rekap P2 dan metadata P2

- `hasil/laporan/REKAP_P2_SEMUA_TAHAP.md` dibuat: menyatukan keempat laporan P2,
  mengikuti struktur `REKAP_SEMUA_TAHAP.md` milik Percobaan 1.
- `hasil/metadata/p2_data.txt` dibuat: SHA-256, jumlah baris, rentang waktu, dan
  catatan keutuhan kedua berkas data P2 (sebelumnya metadata hanya ada untuk P1).
- `hasil/metadata/p2_config_dipakai.py`: salinan `config.py` saat P2 dijalankan.
- `hasil/metadata/p2_perangkat.txt`: perangkat dan versi paket (sama dengan P1,
  tidak ada paket dipasang atau diubah sejak 27 Okt 2026).

Berkas metadata P1 (`data.txt`, `config_dipakai.py`, `perangkat.txt`) tidak disentuh.
