# LAPORAN PERCOBAAN 2 (P2) — TAHAP 2: METODE OPTIMASI

**Dijalankan:** 2026-11-11, 01:34–01:46 WIB (11,3 menit) | **Tag:** `p2_tahap2`  
**Pasangan:** `ticker_5m`, horizon 60 menit — pasangan terpilih di Tahap 1, lihat `LAPORAN_P2_TAHAP1.md`  
**Periode:** 2026-10-10 00:00 s.d. 2026-11-10 16:00 UTC (±31,7 hari)  
**Konfigurasi:** split 80:20, N_TRIALS 30, N_FOLDS 5, seed 42; `grid` memakai 27 kombinasi tetap  
**Jumlah run:** 28 run model (4 model × 7 metode) + 1 baris Naive, semua selesai

> Pasangan `ticker_5m` h60 terpilih lewat **aturan 2** di `KEPUTUSAN_TERKUNCI.md` (tidak ada model yang signifikan lebih baik dari Naive). Jadi seluruh perbandingan di tahap ini berlangsung di titik yang keunggulannya atas Naive belum terbukti signifikan.

---

## 1. MAE vs Naive (%) per metode optimasi

Negatif = lebih akurat dari Naive.

| optimasi | XGBoost | LightGBM | CatBoost | AdaBoost | rata2_4model | rata2_tanpa_AdaBoost |
|---|---|---|---|---|---|---|
| cmaes | -0.251 | -0.140 | -0.284 | -0.749 | -0.356 | -0.225 |
| tpe | -0.284 | -0.221 | -0.330 | 1.186 | 0.088 | -0.279 |
| qmc | -0.235 | -0.325 | -0.259 | 1.215 | 0.099 | -0.273 |
| ga | -0.289 | -0.140 | -0.260 | 1.754 | 0.266 | -0.230 |
| grid | -0.117 | -0.251 | -0.199 | 2.994 | 0.607 | -0.189 |
| random | -0.150 | -0.278 | -0.290 | 5.079 | 1.090 | -0.239 |
| default | 16.915 | 10.804 | 10.235 | 8.310 | 11.566 | 12.651 |

## 2. p-value uji Diebold-Mariano (p_MAE)

| optimasi | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|
| cmaes | 0.429 | 0.462 | 0.176 | 0.380 |
| tpe | 0.422 | 0.361 | 0.137 | 0.352 |
| qmc | 0.417 | 0.228 | 0.187 | 0.434 |
| ga | 0.432 | 0.462 | 0.199 | 0.395 |
| grid | 0.629 | 0.215 | 0.306 | 0.102 |
| random | 0.432 | 0.340 | 0.274 | 0.046 |
| default | 0.000 | 0.003 | 0.002 | 0.002 |

## 3. Waktu tuning dan akurasi arah

| optimasi | total_detik_tuning | rata_akurasi_arah |
|---|---|---|
| cmaes | 98.880 | 56.460 |
| tpe | 54.360 | 56.370 |
| qmc | 124.950 | 56.620 |
| ga | 83.970 | 55.640 |
| grid | 199.460 | 55.060 |
| random | 96.180 | 55.970 |
| default | 8.180 | 52.490 |

## 4. Metode terpilih untuk Tahap 3 dan 4

Aturan terkunci: rata-rata `MAE_vs_naive_pct` keempat model paling kecil; `default` tidak boleh dipilih.

**Metode terpilih: CMA-ES** (`cmaes`) — rata-rata **−0,356%**, satu-satunya metode yang rata-ratanya negatif. Tidak ada seri, jadi aturan pemecah seri (waktu tuning) tidak dipakai. Untuk catatan: CMA-ES justru paling lambat kedua (98,9 detik total, vs TPE 54,4 detik).

## 5. Temuan pokok

**Tuning itu yang penting, bukan metodenya.** Jurang terbesar bukan antar metode, tapi antara `default` dan metode apa pun. Tanpa tuning, MAE membengkak +8% sampai +17% di atas Naive; begitu dituning, semua metode langsung turun ke sekitar −0,1% s.d. −0,3%. Ini temuan paling kokoh di tahap ini.

**Perbedaan antar metode tuning hampir tidak ada untuk tiga model utama.** Rentang antar enam metode (tanpa `default`):

| model | min | max | std |
|---|---|---|---|
| CatBoost | −0,330 | −0,199 | 0,044 |
| LightGBM | −0,325 | −0,140 | 0,074 |
| XGBoost | −0,289 | −0,117 | 0,072 |
| AdaBoost | −0,749 | +5,079 | **1,966** |

Untuk XGBoost, LightGBM, dan CatBoost, selisih metode terbaik dan terburuk hanya ±0,2 poin persen — jauh lebih kecil dari noise, dan tidak ada satu pun yang signifikan (p_MAE terkecil 0,137). Tidak bisa diklaim satu metode lebih baik dari yang lain untuk ketiga model ini.

**Kemenangan CMA-ES praktis seluruhnya datang dari AdaBoost.** Kolom `rata2_tanpa_AdaBoost` membalik urutannya: tanpa AdaBoost, TPE (−0,279) sedikit di atas CMA-ES (−0,225), dan keenam metode berkerumun di −0,19 s.d. −0,28. Yang terjadi: AdaBoost adalah satu-satunya model yang sangat sensitif terhadap metode tuning (std 1,966, rentang −0,75 s.d. +5,08), dan CMA-ES kebetulan menemukan titik yang bagus untuk AdaBoost (−0,749, p = 0,380 — tetap tidak signifikan).

Jadi metode terpilih sah menurut aturan yang dikunci sebelum melihat hasil, tetapi **dasarnya tipis**: satu angka dari satu model yang tidak signifikan. Ini harus ditulis terbuka di skripsi, jangan dibingkai sebagai "CMA-ES terbukti metode optimasi terbaik".

Sebaliknya, satu run signifikan lebih **buruk** dari Naive di luar `default`: AdaBoost + `random` (+5,079%, p = 0,046). Seluruh baris `default` juga signifikan lebih buruk (p ≤ 0,003).

**Nol dari 28 run signifikan lebih baik dari Naive** (kriteria: `MAE_vs_naive_pct < 0` dan `DM_MAE < 0` dan `p_MAE < 0,05`). Konsisten dengan Tahap 1 P2 maupun seluruh Percobaan 1.

## 6. Catatan teknis

- `default` XGBoost paling buruk (+16,9%) karena setelan bawaan (100 pohon, lr 0,3, depth 6) jauh terlalu agresif untuk target return yang hampir seluruhnya noise — modelnya meniru noise data latih.
- LightGBM `cmaes` dan `ga` menghasilkan angka identik (−0,140). Wajar: keduanya diawali beberapa trial acak dengan seed sama, lalu konvergen ke titik yang sama — sudah diantisipasi di catatan metodologi README nomor 5.
- `grid` paling lambat (199 detik) karena 27 kombinasi tetap, bukan 30 trial adaptif.

## 7. Langkah berikutnya

Sesuai aturan terkunci, **berhenti di sini** untuk laporan. Tahap 3 (rasio split) dan Tahap 4 (teknik tambahan) memakai `ticker_5m` h60 + `cmaes`:

```bash
python run.py --datasets ticker_5m --horizons 60 --optimizers cmaes --splits 0.8 0.7 0.6 \
  --start "2026-10-10 00:00" --end "2026-11-10 16:00" --tag p2_tahap3
```

Pertimbangan yang perlu keputusan kamu: karena ketiga model utama tidak bisa dibedakan antar metode, memakai `cmaes` untuk Tahap 3–4 secara teknis benar tapi agak sembarang. Alternatif yang lebih mudah dipertahankan saat sidang: pakai `tpe` (menang bila AdaBoost dikeluarkan, dan paling cepat), atau jalankan Tahap 3–4 untuk `cmaes` **dan** `tpe` lalu laporkan keduanya. Keputusan ini mengubah aturan terkunci, jadi harus kamu atau dosen yang menetapkan — bukan saya.
