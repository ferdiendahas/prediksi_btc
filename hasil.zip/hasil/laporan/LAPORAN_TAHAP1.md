# LAPORAN TAHAP 1 — Mencari Time Frame

**Eksperimen data satu minggu (14–20 Okt 2026).**
Dibuat 2026-10-27. Laporan faktual; tidak memuat interpretasi atau kesimpulan.

---

## 1. Perintah persis yang dijalankan

```bash
source .venv/bin/activate
caffeinate -i python run.py --optimizers tpe --splits 0.8 --tag tahap1
python ringkas.py --tag tahap1 > hasil/laporan/tahap1_ringkasan.txt
```

Perintah `run.py` dijalankan lewat `caffeinate -i` dan keluaran mentahnya disimpan
di `hasil/laporan/tahap1_stdout.txt`. Pengaturan lain diambil dari `config.py`
(salinan di `hasil/metadata/config_dipakai.py`): `N_TRIALS` 30, `N_FOLDS` 5,
`PRUNER` None, `EARLY_STOP` False, `TOP_K` None, `LOSS` l2, `SEED` 42,
periode 2026-10-14 00:00 s.d. 2026-10-20 23:59 UTC.

---

## 2. Waktu

| | |
|---|---|
| Mulai | 2026-10-27 10:09:08 WIB |
| Selesai | 2026-10-27 10:19:54 WIB |
| Durasi total (wall clock) | 10 menit 46 detik (10,7 menit) |
| Jumlah `detik_total` semua run | 643,6 detik |
| Jumlah `detik_tuning` semua run | 636,5 detik |
| Exit code | 0 |

Durasi jauh di bawah perkiraan brief (1–3 jam). Perangkat: Apple M5, 10 core,
16 GB RAM (`hasil/metadata/perangkat.txt`).

---

## 3. Jumlah run

| | |
|---|---|
| Direncanakan (brief) | 36 (9 pasangan dataset×horizon × 4 model) |
| Maksimum menurut `run.py` | 40 (2 dataset × 5 horizon × 1 split × 4 model × 1 metode) |
| Dilewati karena kombinasi tidak valid | 4 (`ticker_5m` horizon 1 menit, bukan kelipatan TF 5 menit) |
| Selesai | 36 |
| Gagal | 0 |

Tidak ada pesan error. Baris Naive yang dicatat: 9 (satu per pasangan
dataset×horizon pada split 80:20). Total baris di `hasil/hasil_semua.csv`: 45.

Setiap run memakai `n_trials` = 30 dan `n_pruned` = 0 (pruner tidak aktif).
Jumlah fitur: `candle_1m` 42, `ticker_5m` 32.

---

## 4. Tabel lengkap semua run Tahap 1

Persen dibulatkan 3 desimal, rupiah bilangan bulat, p-value 4 desimal.
`MAE_vs_naive_pct` negatif = MAE lebih kecil daripada Naive.
`DM_MAE` negatif = model lebih akurat daripada Naive pada loss absolut.

| dataset | horizon_menit | split | model | optimasi | MAE_Rp | RMSE_Rp | MAPE_pct | Akurasi_arah_pct | MAE_vs_naive_pct | RMSE_vs_naive_pct | DM_MAE | p_MAE | DM_RMSE | p_RMSE | n_latih | n_uji | n_trials | detik_total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 92.0 |
| candle_1m | 1 | 80:20 | CatBoost | tpe | 348,066 | 622,845 | 0.024 | 56.818 | -0.347 | -2.151 | -0.85 | 0.3952 | -6.193 | 0.0 | 8,062 | 2,016 | 30 | 65.9 |
| candle_1m | 1 | 80:20 | LightGBM | tpe | 348,157 | 625,799 | 0.024 | 56.699 | -0.321 | -1.687 | -1.044 | 0.2964 | -6.32 | 0.0 | 8,062 | 2,016 | 30 | 4.7 |
| candle_1m | 1 | 80:20 | XGBoost | tpe | 348,262 | 618,940 | 0.024 | 57.476 | -0.291 | -2.765 | -0.546 | 0.5848 | -6.128 | 0.0 | 8,062 | 2,016 | 30 | 63.7 |
| candle_1m | 5 | 80:20 | AdaBoost | tpe | 772,473 | 1,359,292 | 0.052 | 50.66 | 1.089 | 0.234 | 2.147 | 0.0319 | 1.303 | 0.1928 | 8,055 | 2,015 | 30 | 44.0 |
| candle_1m | 5 | 80:20 | CatBoost | tpe | 764,611 | 1,355,656 | 0.052 | 51.135 | 0.06 | -0.034 | 0.952 | 0.341 | -0.617 | 0.5375 | 8,055 | 2,015 | 30 | 9.5 |
| candle_1m | 5 | 80:20 | LightGBM | tpe | 764,858 | 1,356,212 | 0.052 | 50.66 | 0.093 | 0.007 | 3.49 | 0.0005 | 0.374 | 0.7084 | 8,055 | 2,015 | 30 | 4.6 |
| candle_1m | 5 | 80:20 | XGBoost | tpe | 764,678 | 1,356,361 | 0.052 | 52.243 | 0.069 | 0.018 | 0.66 | 0.5092 | 0.206 | 0.8364 | 8,055 | 2,015 | 30 | 11.6 |
| candle_1m | 15 | 80:20 | AdaBoost | tpe | 1,411,819 | 2,391,727 | 0.096 | 49.036 | 0.35 | 0.076 | 1.681 | 0.0929 | 0.466 | 0.641 | 8,037 | 2,013 | 30 | 43.0 |
| candle_1m | 15 | 80:20 | CatBoost | tpe | 1,409,464 | 2,389,233 | 0.096 | 48.782 | 0.183 | -0.029 | 1.171 | 0.2418 | -0.159 | 0.8734 | 8,037 | 2,013 | 30 | 9.5 |
| candle_1m | 15 | 80:20 | LightGBM | tpe | 1,408,067 | 2,390,167 | 0.095 | 50.508 | 0.084 | 0.01 | 0.508 | 0.6118 | 0.049 | 0.961 | 8,037 | 2,013 | 30 | 6.0 |
| candle_1m | 15 | 80:20 | XGBoost | tpe | 1,408,759 | 2,390,834 | 0.095 | 49.036 | 0.133 | 0.038 | 1.392 | 0.1642 | 0.407 | 0.6842 | 8,037 | 2,013 | 30 | 6.3 |
| candle_1m | 30 | 80:20 | AdaBoost | tpe | 2,028,617 | 3,407,769 | 0.137 | 49.373 | 0.439 | 0.245 | 0.82 | 0.4123 | 0.452 | 0.651 | 8,010 | 2,010 | 30 | 42.5 |
| candle_1m | 30 | 80:20 | CatBoost | tpe | 2,029,219 | 3,390,982 | 0.138 | 48.471 | 0.469 | -0.248 | 0.481 | 0.6305 | -0.21 | 0.8334 | 8,010 | 2,010 | 30 | 13.8 |
| candle_1m | 30 | 80:20 | LightGBM | tpe | 2,020,945 | 3,400,423 | 0.137 | 49.023 | 0.059 | 0.029 | 0.759 | 0.4478 | 0.407 | 0.6839 | 8,010 | 2,010 | 30 | 5.9 |
| candle_1m | 30 | 80:20 | XGBoost | tpe | 2,019,946 | 3,396,990 | 0.137 | 53.133 | 0.01 | -0.072 | 0.029 | 0.9772 | -0.229 | 0.8188 | 8,010 | 2,010 | 30 | 9.9 |
| candle_1m | 60 | 80:20 | AdaBoost | tpe | 3,009,270 | 4,841,380 | 0.204 | 49.65 | 0.104 | 0.148 | 0.207 | 0.836 | 0.402 | 0.6877 | 7,956 | 2,004 | 30 | 51.4 |
| candle_1m | 60 | 80:20 | CatBoost | tpe | 3,018,493 | 4,870,407 | 0.204 | 44.144 | 0.411 | 0.748 | 0.742 | 0.458 | 0.863 | 0.3883 | 7,956 | 2,004 | 30 | 9.4 |
| candle_1m | 60 | 80:20 | LightGBM | tpe | 3,001,349 | 4,835,678 | 0.203 | 50.15 | -0.159 | 0.03 | -0.292 | 0.77 | 0.06 | 0.952 | 7,956 | 2,004 | 30 | 9.0 |
| candle_1m | 60 | 80:20 | XGBoost | tpe | 3,012,358 | 4,848,611 | 0.204 | 47.247 | 0.207 | 0.297 | 0.234 | 0.8148 | 0.296 | 0.7673 | 7,956 | 2,004 | 30 | 14.3 |
| ticker_5m | 5 | 80:20 | AdaBoost | tpe | 638,607 | 1,265,698 | 0.043 | 51.831 | 0.541 | -0.358 | 2.578 | 0.0103 | -1.914 | 0.0564 | 1,611 | 403 | 30 | 22.4 |
| ticker_5m | 5 | 80:20 | CatBoost | tpe | 641,795 | 1,263,277 | 0.044 | 52.113 | 1.043 | -0.549 | 3.009 | 0.0028 | -2.298 | 0.0221 | 1,611 | 403 | 30 | 18.8 |
| ticker_5m | 5 | 80:20 | LightGBM | tpe | 637,497 | 1,267,941 | 0.043 | 49.859 | 0.366 | -0.182 | 3.241 | 0.0013 | -2.658 | 0.0082 | 1,611 | 403 | 30 | 5.4 |
| ticker_5m | 5 | 80:20 | XGBoost | tpe | 636,191 | 1,269,149 | 0.043 | 52.676 | 0.16 | -0.087 | 2.611 | 0.0094 | -2.074 | 0.0387 | 1,611 | 403 | 30 | 6.2 |
| ticker_5m | 15 | 80:20 | AdaBoost | tpe | 1,343,102 | 2,385,663 | 0.091 | 49.235 | 2.554 | 2.466 | 1.337 | 0.1819 | 1.243 | 0.2145 | 1,607 | 403 | 30 | 6.9 |
| ticker_5m | 15 | 80:20 | CatBoost | tpe | 1,320,016 | 2,342,865 | 0.09 | 51.276 | 0.792 | 0.628 | 1.422 | 0.1557 | 1.413 | 0.1585 | 1,607 | 403 | 30 | 6.7 |
| ticker_5m | 15 | 80:20 | LightGBM | tpe | 1,311,375 | 2,329,055 | 0.089 | 46.939 | 0.132 | 0.035 | 1.693 | 0.0912 | 0.724 | 0.4697 | 1,607 | 403 | 30 | 7.3 |
| ticker_5m | 15 | 80:20 | XGBoost | tpe | 1,313,167 | 2,330,877 | 0.089 | 45.408 | 0.269 | 0.113 | 1.966 | 0.05 | 1.2 | 0.2309 | 1,607 | 403 | 30 | 6.2 |
| ticker_5m | 30 | 80:20 | AdaBoost | tpe | 1,949,283 | 3,409,246 | 0.132 | 49.749 | 0.447 | 0.597 | 0.902 | 0.3675 | 0.675 | 0.5001 | 1,602 | 402 | 30 | 8.3 |
| ticker_5m | 30 | 80:20 | CatBoost | tpe | 1,941,960 | 3,393,938 | 0.132 | 48.744 | 0.069 | 0.145 | 0.709 | 0.479 | 0.692 | 0.4896 | 1,602 | 402 | 30 | 5.3 |
| ticker_5m | 30 | 80:20 | LightGBM | tpe | 1,941,556 | 3,390,532 | 0.132 | 51.005 | 0.049 | 0.044 | 0.87 | 0.3849 | 0.717 | 0.4736 | 1,602 | 402 | 30 | 3.2 |
| ticker_5m | 30 | 80:20 | XGBoost | tpe | 1,941,262 | 3,389,729 | 0.132 | 48.744 | 0.034 | 0.021 | 0.49 | 0.6241 | 0.381 | 0.7033 | 1,602 | 402 | 30 | 6.4 |
| ticker_5m | 60 | 80:20 | AdaBoost | tpe | 2,990,733 | 4,849,904 | 0.203 | 48.379 | 0.333 | 0.51 | 0.527 | 0.5986 | 1.208 | 0.2279 | 1,591 | 401 | 30 | 8.8 |
| ticker_5m | 60 | 80:20 | CatBoost | tpe | 2,981,290 | 4,829,706 | 0.202 | 51.621 | 0.017 | 0.091 | 0.149 | 0.8815 | 0.723 | 0.4701 | 1,591 | 401 | 30 | 6.5 |
| ticker_5m | 60 | 80:20 | LightGBM | tpe | 2,981,272 | 4,825,899 | 0.202 | 47.88 | 0.016 | 0.012 | 0.281 | 0.7791 | 0.309 | 0.7571 | 1,591 | 401 | 30 | 4.0 |
| ticker_5m | 60 | 80:20 | XGBoost | tpe | 2,983,097 | 4,829,723 | 0.202 | 48.379 | 0.077 | 0.091 | 0.716 | 0.4744 | 0.707 | 0.4798 | 1,591 | 401 | 30 | 3.9 |

---

## 5. Baris Naive per (dataset, horizon, split)

| dataset | horizon_menit | split | MAE_Rp | RMSE_Rp | MAPE_pct | n_latih | n_uji | uji_mulai | uji_akhir |
|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 | 2026-10-19 14:23:00 | 2026-10-20 23:58:00 |
| candle_1m | 5 | 80:20 | 764,151 | 1,356,121 | 0.052 | 8,055 | 2,015 | 2026-10-19 14:20:00 | 2026-10-20 23:54:00 |
| candle_1m | 15 | 80:20 | 1,406,890 | 2,389,920 | 0.095 | 8,037 | 2,013 | 2026-10-19 14:12:00 | 2026-10-20 23:44:00 |
| candle_1m | 30 | 80:20 | 2,019,749 | 3,399,424 | 0.137 | 8,010 | 2,010 | 2026-10-19 14:00:00 | 2026-10-20 23:29:00 |
| candle_1m | 60 | 80:20 | 3,006,141 | 4,834,244 | 0.204 | 7,956 | 2,004 | 2026-10-19 13:36:00 | 2026-10-20 22:59:00 |
| ticker_5m | 5 | 80:20 | 635,172 | 1,270,250 | 0.043 | 1,611 | 403 | 2026-10-19 14:20:00 | 2026-10-20 23:50:00 |
| ticker_5m | 15 | 80:20 | 1,309,648 | 2,328,251 | 0.089 | 1,607 | 403 | 2026-10-19 14:10:00 | 2026-10-20 23:40:00 |
| ticker_5m | 30 | 80:20 | 1,940,612 | 3,389,026 | 0.132 | 1,602 | 402 | 2026-10-19 14:00:00 | 2026-10-20 23:25:00 |
| ticker_5m | 60 | 80:20 | 2,980,794 | 4,825,316 | 0.202 | 1,591 | 401 | 2026-10-19 13:35:00 | 2026-10-20 22:55:00 |

Catatan: periode uji berbeda antar horizon karena jumlah baris setelah
`dropna()` dan *purging* berbeda; `n_latih` pada tabel ini adalah jumlah baris
latih setelah pembuangan h bar terakhir.

---

## 6. Penerapan aturan pemilihan (bagian 4 brief)

Definisi yang dipakai, apa adanya dari `hasil/KEPUTUSAN_TERKUNCI.md`:

- **Signifikan lebih baik dari Naive** = `MAE_vs_naive_pct < 0` **dan** `DM_MAE < 0`
  **dan** `p_MAE < 0.05`.
- **Skor pasangan** (dataset, horizon) = `MAE_vs_naive_pct` terkecil di antara
  keempat model pada pasangan itu.

### Langkah 1 — cari run yang signifikan lebih baik dari Naive

Run dengan `MAE_vs_naive_pct < 0` ada 5 dari 36:

| dataset | horizon | model | MAE_vs_naive_pct | DM_MAE | p_MAE | p_MAE < 0,05? |
|---|---|---|---|---|---|---|
| candle_1m | 1 | CatBoost | -0.347 | -0.850 | 0.3952 | tidak |
| candle_1m | 1 | LightGBM | -0.321 | -1.044 | 0.2964 | tidak |
| candle_1m | 1 | XGBoost | -0.291 | -0.546 | 0.5848 | tidak |
| candle_1m | 60 | LightGBM | -0.159 | -0.292 | 0.7700 | tidak |
| candle_1m | 1 | AdaBoost | -0.066 | -0.130 | 0.8966 | tidak |

Ketiga syarat terpenuhi bersamaan pada **0 run**. Semua lima run di atas memenuhi
`MAE_vs_naive_pct < 0` dan `DM_MAE < 0`, tetapi tidak satu pun memenuhi
`p_MAE < 0.05`.

**Aturan 1 tidak berlaku. Tidak ada model yang signifikan lebih baik dari Naive.**

### Langkah 2 — aturan 2 dipakai

Aturan 2: pilih pasangan dengan skor terkecil, dan tulis jelas di laporan
**"tidak ada model yang signifikan lebih baik dari Naive"** — pernyataan itu
dicatat di Langkah 1 di atas.

Skor seluruh pasangan, urut dari terkecil:

| peringkat | dataset | horizon (menit) | skor = min MAE_vs_naive_pct | model pembawa skor |
|---|---|---|---|---|
| 1 | candle_1m | 1 | **-0.347** | CatBoost |
| 2 | candle_1m | 60 | -0.159 | LightGBM |
| 3 | candle_1m | 30 | 0.010 | XGBoost |
| 4 | ticker_5m | 60 | 0.016 | LightGBM |
| 5 | ticker_5m | 30 | 0.034 | XGBoost |
| 6 | candle_1m | 5 | 0.060 | CatBoost |
| 7 | candle_1m | 15 | 0.084 | LightGBM |
| 8 | ticker_5m | 15 | 0.132 | LightGBM |
| 9 | ticker_5m | 5 | 0.160 | XGBoost |

### Langkah 3 — cek seri

Skor terkecil (-0.346974) hanya dimiliki satu pasangan. **Aturan 3 (penyelesaian
seri) tidak perlu dipakai.**

### Pilihan akhir Tahap 1

| | |
|---|---|
| Aturan yang dipakai | **Aturan 2** |
| Dataset terpilih | **`candle_1m`** |
| Horizon terpilih | **1 menit** |
| Skor pasangan | -0.346974 (CatBoost) |
| Status signifikansi | tidak ada model yang signifikan lebih baik dari Naive |

Perintah Tahap 2 yang mengikuti pilihan ini:

```bash
python run.py --datasets candle_1m --horizons 1 --splits 0.8 \
  --optimizers default grid random tpe cmaes ga qmc --tag tahap2
```

---

## 7. Hyperparameter terbaik untuk konfigurasi terpilih

Konfigurasi terpilih: `candle_1m`, harga `typical`, horizon 1 menit, split 80:20,
optimasi `tpe`, `loss` l2, tanpa early stopping, tanpa seleksi fitur, tanpa pruner,
30 trial, 5 fold. Semua model memakai 42 fitur. Sumber: `hasil/params/`.

| model | cv_mae_return | hyperparameter terbaik |
|---|---|---|
| XGBoost | 0.000223 | `n_estimators` 452, `max_depth` 7, `learning_rate` 0.0031346, `min_child_weight` 48, `subsample` 0.74621, `colsample_bytree` 0.55215, `reg_lambda` 0.30546, `reg_alpha` 0.0053916 |
| LightGBM | 0.000224 | `n_estimators` 27, `num_leaves` 25, `max_depth` 7, `learning_rate` 0.014728, `min_child_samples` 28, `subsample` 0.59400, `colsample_bytree` 0.92573, `reg_lambda` 4.22932, `reg_alpha` 0.0034210, `subsample_freq` 1 |
| CatBoost | 0.000224 | `iterations` 420, `depth` 8, `learning_rate` 0.0016139, `l2_leaf_reg` 0.10368, `random_strength` 1.18432, `bagging_temperature` 0.56779 |
| AdaBoost | 0.000224 | `n_estimators` 32, `learning_rate` 0.0019634, `loss` linear, `max_depth` 3 |

Nama file lengkap di `hasil/params/` berpola
`candle_1m__typical__h1__80-20__<model>__tpe__l2__es0__k0__prnone__t30__f5__2026-10-14_00-00__2026-10-20_23-59__tahap1.json`.

---

## 8. Catatan teknis

1. **`std_pred_return` = 0 persis pada dua run.** `candle_1m` horizon 15 menit
   AdaBoost dan `candle_1m` horizon 60 menit AdaBoost menghasilkan
   `std_pred_return` = 0,0 — prediksi return benar-benar konstan untuk seluruh data
   uji, sehingga prediksi rupiah sama dengan Naive dikali satu konstanta.
   `Akurasi_arah_pct` pada kedua run itu 49,036% dan 49,650%.

2. **Tiga run lain praktis konstan** (`std_pred_return` di orde 1e-21, yaitu nol
   dalam presisi mesin): `candle_1m` h5 LightGBM (1,27e-21), `ticker_5m` h60
   LightGBM (1,69e-21), `candle_1m` h30 LightGBM (3,39e-21). Satu run di orde
   1e-13: `ticker_5m` h30 XGBoost (9,09e-13).

3. **Untuk pasangan terpilih (`candle_1m` h1) tidak ada masalah ini.**
   `std_pred_return` keempat model berada di orde 3e-05 s.d. 6e-05
   (XGBoost 5,85e-05; AdaBoost 5,58e-05; CatBoost 4,44e-05; LightGBM 3,31e-05),
   sedangkan `cv_mae_return` keempatnya 0,000223–0,000224.

4. **`p_RMSE` signifikan pada horizon 1 menit `candle_1m` untuk keempat model**
   (p_RMSE = 0,0000 pada XGBoost, LightGBM, CatBoost, AdaBoost; `RMSE_vs_naive_pct`
   -2,765%, -1,687%, -2,151%, -2,058%). Ini dicatat sebagai fakta; metrik utama
   yang dipakai aturan pemilihan tetap `MAE_vs_naive_pct` dan `p_MAE`.

5. **Run paling lama**: `candle_1m` h1 AdaBoost 92,0 detik, `candle_1m` h1 CatBoost
   65,9 detik, `candle_1m` h1 XGBoost 63,7 detik. Tidak ada run yang melebihi
   2 menit.

6. **Tidak ada warning yang muncul di stdout.** `run.py` memasang
   `warnings.filterwarnings("ignore")` di awal berkas, jadi warning library tidak
   tertangkap di `hasil/laporan/tahap1_stdout.txt`.

7. **Tabel `optimasi_x_model` dan `split_x_model` di
   `hasil/laporan/tahap1_ringkasan.txt` masing-masing hanya berisi satu baris**
   (`tpe` dan `80:20`), karena Tahap 1 memang hanya menjalankan satu metode
   optimasi dan satu rasio split. Bukan run yang hilang.

8. **Jumlah baris uji berbeda antar horizon** (misalnya `candle_1m` 2.016 baris di
   h1 dan 2.004 baris di h60) karena jumlah baris yang terbuang oleh `dropna()`
   dan *purging* bergantung pada horizon. Perbandingan MAE rupiah antar horizon
   karena itu tidak setara; yang dibandingkan dalam aturan pemilihan hanya
   `MAE_vs_naive_pct`, yang dihitung terhadap Naive pada periode uji yang sama.

---

## 9. Berkas yang dihasilkan Tahap 1

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | 45 baris (36 run model + 9 baris Naive), semua bertag `tahap1` |
| `hasil/laporan/LAPORAN_TAHAP1.md` | laporan ini |
| `hasil/laporan/tahap1_ringkasan.txt` | keluaran `ringkas.py --tag tahap1` |
| `hasil/laporan/tahap1_stdout.txt` | keluaran mentah `run.py` |
| `hasil/laporan/tahap1_waktu.txt` | waktu mulai dan selesai |
| `hasil/params/` | 36 berkas JSON (hyperparameter terbaik + daftar fitur per run) |
| `hasil/prediksi/` | 36 berkas CSV prediksi data uji per run |
| `hasil/ringkasan/` | `horizon_x_model.csv`, `optimasi_x_model.csv`, `split_x_model.csv`, `peringkat.csv` |
