# LAPORAN PERCOBAAN 2 (P2) — TAHAP 4: TEKNIK OPTIMASI TAMBAHAN

**Dijalankan:** 2026-11-11, 02:14–02:25 WIB (10,1 menit) | **Tag:** `p2_tahap4_*`  
**Pasangan:** `ticker_5m`, horizon 60 menit, split 80:20 | **Periode:** 2026-10-10 00:00 s.d. 2026-11-10 16:00 UTC  
**Metode optimasi:** `cmaes` dan `tpe` | **Jumlah run:** 32 (4 teknik × 2 metode × 4 model), semua selesai

Tiap teknik diuji **terpisah** (tidak digabung), pembandingnya hasil Tahap 2 dengan metode yang sama. Sesuai aturan terkunci: **tidak ada pemilihan**, hanya pelaporan selisih.

---

## 1. Baseline (Tahap 2, tanpa teknik tambahan)

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.251 | -0.284 |
| LightGBM | -0.140 | -0.221 |
| CatBoost | -0.284 | -0.330 |
| AdaBoost | -0.749 | 1.186 |

## 2. Selisih tiap teknik terhadap baseline

Negatif = teknik memperbaiki (MAE makin unggul atas Naive).

### Early stopping

MAE vs Naive (%):

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.528 | -0.461 |
| LightGBM | -0.490 | -0.268 |
| CatBoost | 0.105 | -0.249 |
| AdaBoost | -0.749 | 1.186 |

Selisih vs baseline:

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.278 | -0.177 |
| LightGBM | -0.349 | -0.047 |
| CatBoost | 0.389 | 0.081 |
| AdaBoost | 0.000 | 0.000 |

Run berstatus DATAR: **0 dari 8**

### Seleksi 15 fitur teratas

MAE vs Naive (%):

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.151 | -0.210 |
| LightGBM | -0.302 | -0.282 |
| CatBoost | -0.333 | -0.271 |
| AdaBoost | -0.418 | 2.203 |

Selisih vs baseline:

| model | cmaes | tpe |
|---|---|---|
| XGBoost | 0.100 | 0.074 |
| LightGBM | -0.161 | -0.061 |
| CatBoost | -0.050 | 0.059 |
| AdaBoost | 0.331 | 1.016 |

Run berstatus DATAR: **1 dari 8**

### Loss L1 (absolute error)

MAE vs Naive (%):

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.117 | -0.117 |
| LightGBM | -0.111 | -0.132 |
| CatBoost | -0.087 | -0.105 |
| AdaBoost | -0.749 | 1.186 |

Selisih vs baseline:

| model | cmaes | tpe |
|---|---|---|
| XGBoost | 0.134 | 0.167 |
| LightGBM | 0.030 | 0.089 |
| CatBoost | 0.197 | 0.226 |
| AdaBoost | 0.000 | 0.000 |

Run berstatus DATAR: **5 dari 8**

### Pruner median

MAE vs Naive (%):

| model | cmaes | tpe |
|---|---|---|
| XGBoost | -0.140 | -0.284 |
| LightGBM | -0.140 | -0.221 |
| CatBoost | -0.291 | -0.330 |
| AdaBoost | 1.157 | 1.186 |

Selisih vs baseline:

| model | cmaes | tpe |
|---|---|---|
| XGBoost | 0.110 | 0.000 |
| LightGBM | 0.000 | 0.000 |
| CatBoost | -0.008 | 0.000 |
| AdaBoost | 1.906 | 0.000 |

Run berstatus DATAR: **3 dari 8**

## 3. Temuan pokok

### 3a. Satu run akhirnya signifikan lebih baik dari Naive — yang pertama di seluruh Percobaan 2

**LightGBM + loss L1 + CMA-ES**: MAE Rp3.541.748 vs Naive Rp3.545.674 → **−0,111%**, DM_MAE −2,104, **p_MAE = 0,0355**. Ini memenuhi kriteria terkunci (`MAE_vs_naive_pct < 0` dan `DM_MAE < 0` dan `p_MAE < 0,05`) — satu-satunya dari 120 run P2 (36+28+24+32).

Tiga run L1 lain nyaris lolos: LightGBM+`tpe` p = 0,100, CatBoost+`cmaes` p = 0,062, CatBoost+`tpe` p = 0,061. Keempatnya di teknik yang sama, jadi ini **pola, bukan kebetulan satu run**.

**Penyebabnya bisa dijelaskan, dan penjelasannya mengurangi bobot temuan.** Metrik utama penelitian ini MAE, dan L1 adalah loss yang persis mengoptimalkan MAE. Jadi yang terjadi: menyamakan fungsi loss saat latih dengan metrik saat evaluasi akhirnya menghasilkan keunggulan yang terdeteksi uji statistik. Bukti pendukungnya kuat:

- `RMSE_vs_naive_pct` run itu hanya **−0,002%** dengan **p_RMSE = 0,96** — nol keunggulan pada error kuadrat. Kalau model benar-benar menangkap pergerakan harga, RMSE ikut membaik.
- `rasio_sebaran` = 5,8e−03, artinya prediksinya hanya bergerak **0,58%** sebesar pergerakan harga sebenarnya. Statusnya **DATAR**.
- `geser_rata2` = −2e−06, praktis nol, jadi keunggulan ini **bukan** dari menunggangi tren turun seperti di Tahap 3.

Yang tersisa sebagai penjelasan: L1 menarik prediksi ke median kondisional return, yang sedikit bergeser dari nol. Menebak median yang nyaris-nol mengalahkan menebak nol persis pada loss absolut — konsisten, terdeteksi statistik, dan tidak memerlukan kemampuan memprediksi arah per waktu.

### 3b. Besarnya keunggulan tidak berarti secara praktis

| | nilai |
|---|---|
| Penghematan MAE | Rp3.926 per prediksi |
| Relatif terhadap harga | 0,00028% |
| Rata-rata spread bid-ask di periode uji | Rp599.762 (0,0433% dari harga) |
| Penghematan ÷ spread | **0,01×** |

Keunggulannya **153 kali lebih kecil dari spread bid-ask**. Seorang trader yang bertransaksi berdasarkan prediksi ini akan kehilangan jauh lebih banyak di spread daripada yang diperoleh dari akurasi. Jadi kesimpulan yang sah: *signifikan secara statistik, tidak berarti secara ekonomi.* Dua-duanya harus ditulis; menulis yang pertama saja menyesatkan.

### 3c. Early stopping satu-satunya teknik yang membuat model benar-benar memprediksi

**0 dari 8 run DATAR** — satu-satunya teknik dengan nol model datar. Sekaligus perbaikan terbesar untuk dua model: XGBoost −0,528 (dari −0,251) dan LightGBM −0,490 (dari −0,140). Masuk akal secara mekanis: jumlah pohon ditentukan oleh error validasi, bukan oleh tuning yang cenderung memilih model sangat kecil + regularisasi besar (yang menghasilkan prediksi datar).

Tetapi keunggulannya tetap tidak signifikan (p terbaik 0,114), dan **CatBoost justru memburuk** (+0,389 dengan `cmaes`, jadi +0,105 — di atas Naive). Jadi tidak bisa disebut teknik yang seragam membantu.

### 3d. Loss L1 membuat model kolaps jadi datar

**5 dari 8 run DATAR**, terburuk di antara keempat teknik. XGBoost+L1 mengeluarkan **satu nilai identik** untuk seluruh 1.822 baris uji (`n_unik` = 1), di kedua metode optimasi. Ini sisi lain dari 3a: L1 memang menarik prediksi ke median, dan kalau mediannya nol, modelnya berhenti memprediksi sama sekali.

### 3e. Seleksi 15 fitur: netral

Selisih berkisar −0,161 s.d. +0,100 untuk tiga model utama, berganti-ganti arah tanpa pola. Membuang 17 dari 32 fitur hampir tidak mengubah apa pun — tanda bahwa fitur-fitur itu memang tidak membawa banyak informasi, bukan tanda seleksinya bagus. AdaBoost memburuk (+0,331 dan +1,016).

### 3f. Pruner median: tidak mengubah hasil, hanya mempercepat

Dengan `tpe`, selisihnya **0,000 untuk keempat model** — identik dengan baseline, padahal 6–12 trial dipangkas. Artinya trial yang dipangkas memang trial jelek yang tidak akan jadi pemenang; pruner bekerja sebagaimana mestinya. Dengan `cmaes` 10–22 trial dipangkas dan hasilnya sedikit bergeser (AdaBoost memburuk +1,906).

Catatan: `n_pruned` di baseline Tahap 2 adalah 0 untuk semua run, jadi perbandingan ini bersih.

### 3g. AdaBoost memang mengabaikan dua teknik

Selisih AdaBoost pada `early-stop` dan `loss l1` tepat **0,000** di kedua metode. Ini bukan bug — sesuai catatan metodologi README nomor 7, AdaBoost.R2 tidak memakai `LOSS` dan `EARLY_STOP`; parameter `loss`-nya sendiri (linear/square/exponential) sudah ikut dituning. Jadi kedua kolom itu memang harus identik, dan kenyataannya identik — sekaligus jadi uji kewarasan bahwa pipeline berjalan benar.

## 4. Ringkasan seluruh Percobaan 2

| tahap | run | signifikan > Naive | DATAR |
|---|---|---|---|
| Tahap 1 (time frame) | 36 | 0 | 21 |
| Tahap 2 (metode optimasi) | 28 | 0 | 6 |
| Tahap 3 (rasio split) | 24 | 0 | 8 |
| Tahap 4 (teknik tambahan) | 32 | **1** | 9 |
| **total** | **120** | **1** | **44** |

Satu dari 120 run signifikan mengalahkan Naive, dan run itu sendiri berstatus DATAR dengan keunggulan 153× lebih kecil dari spread. **37% dari seluruh run adalah model datar** — angka yang wajib dilaporkan, karena tanpa pemeriksaan ini sebagian dari run tersebut terbaca sebagai "menang tipis dari Naive" di tabel MAE.

## 5. Catatan untuk Bab 4 dan 5

1. Pernyataan yang didukung data: *keempat model boosting tidak mampu mengalahkan Naive secara meyakinkan untuk prediksi harga BTC/IDR 60 menit ke depan; satu-satunya keunggulan yang signifikan secara statistik berukuran jauh di bawah biaya transaksi.* Ini kesimpulan negatif yang valid dan layak, bukan kegagalan penelitian.
2. Yang **tidak** boleh ditulis: "model berhasil memprediksi harga", "CMA-ES terbukti metode terbaik", atau menonjolkan run L1 tanpa menyebut p_RMSE 0,96 dan status DATAR-nya.
3. Faktor pembatas terbesar menurut bukti yang ada: bukan pilihan model atau metode optimasi, melainkan **rasio sinyal terhadap noise pada return jangka pendek**. Bukti: perbedaan antar metode optimasi < 0,2 poin persen (Tahap 2), antar rasio split hanya menggeser seberapa datar modelnya (Tahap 3), dan 37% run berakhir datar.
4. Saran arah lanjutan bila ingin hasil positif: horizon lebih panjang (harian), atau target klasifikasi arah dengan ambang di luar spread, bukan regresi harga.
