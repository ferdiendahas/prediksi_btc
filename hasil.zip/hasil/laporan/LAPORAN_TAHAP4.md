# LAPORAN TAHAP 4 — Teknik Optimasi Tambahan

**Eksperimen data satu minggu (14–20 Okt 2026).**
Dibuat 2026-10-28. Laporan faktual; tidak memuat interpretasi atau kesimpulan.

Pasangan dan metode dari tahap sebelumnya: **`candle_1m`, horizon 1 menit,
split 80:20** (Tahap 1) dan **metode optimasi `tpe`** (Tahap 2).
Pembanding setiap teknik adalah **hasil Tahap 2 untuk metode `tpe`**.

**Tahap ini tidak memiliki aturan pemilihan.** Selisih tiap teknik dilaporkan apa adanya.

---

## 1. Perintah persis yang dijalankan

```bash
source .venv/bin/activate
caffeinate -i python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --early-stop    --tag tahap4_earlystop
caffeinate -i python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --top-k 15      --tag tahap4_topk15
caffeinate -i python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --loss l1       --tag tahap4_lossl1
caffeinate -i python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --pruner median --tag tahap4_prunermedian

python ringkas.py --tag tahap4_earlystop    > hasil/laporan/tahap4_earlystop_ringkasan.txt
python ringkas.py --tag tahap4_topk15       > hasil/laporan/tahap4_topk15_ringkasan.txt
python ringkas.py --tag tahap4_lossl1       > hasil/laporan/tahap4_lossl1_ringkasan.txt
python ringkas.py --tag tahap4_prunermedian > hasil/laporan/tahap4_prunermedian_ringkasan.txt
```

Keluaran mentah di `hasil/laporan/tahap4_<nama>_stdout.txt`. Pengaturan lain dari
`config.py`: `N_TRIALS` 30, `N_FOLDS` 5, `SEED` 42, periode 2026-10-14 00:00 s.d.
2026-10-20 23:59 UTC.

---

## 2. Waktu

| Teknik | Mulai | Selesai | Durasi |
|---|---|---|---|
| `--early-stop` | 07:42:32 | 07:53:28 | 10 m 56 s |
| `--top-k 15` | 07:53:28 | 08:12:03 | 18 m 35 s |
| `--loss l1` | 08:12:03 | 08:14:48 | 2 m 45 s |
| `--pruner median` | 08:14:48 | 08:17:18 | 2 m 30 s |
| **Total** | **2026-10-28 07:42:32** | **2026-10-28 08:17:18** | **34 m 46 s** |

Semua exit code 0.

---

## 3. Jumlah run

| | |
|---|---|
| Direncanakan (brief) | 16 (4 teknik × 4 model) |
| Selesai | **16** |
| Gagal | **0** |

Baris Naive yang dicatat: 4 (satu per tag). Total baris bertag `tahap4_*`: 20.
Total baris `hasil/hasil_semua.csv`: 109 (92 run model + 17 baris Naive).

### Catatan kegagalan perintah (bukan kegagalan run)

Upaya pertama menjalankan Tahap 4 memakai satu perintah shell dengan variabel
`$B` berisi bagian perintah yang dipakai bersama. Di **zsh** parameter tak terkutip
tidak dipecah menjadi kata (berbeda dari bash), sehingga seluruh isi `$B` dianggap
satu nama program dan keempat perintah gagal seketika dengan:

```
.venv/bin/python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8: No such file or directory
```

Waktu: 2026-10-28 07:42:02, keempatnya gagal dalam detik yang sama.
**Tidak ada run yang tercatat** dari upaya ini (`hasil_semua.csv` tetap 89 baris,
diverifikasi sebelum menjalankan ulang), jadi tidak ada baris yang perlu dibuang.
Perintah ditulis ulang secara eksplisit tanpa variabel, lalu keempatnya berhasil.
Berkas stdout kosong dari upaya gagal (`tahap4_early-stop_stdout.txt`, dengan tanda
hubung) sudah dihapus agar tidak tertukar dengan `tahap4_earlystop_stdout.txt`.

---

## 4. Tabel lengkap semua run Tahap 4

Persen dibulatkan 3 desimal, rupiah bilangan bulat, p-value 4 desimal.

| teknik | dataset | horizon_menit | split | model | optimasi | MAE_Rp | RMSE_Rp | MAPE_pct | Akurasi_arah_pct | MAE_vs_naive_pct | RMSE_vs_naive_pct | DM_MAE | p_MAE | DM_RMSE | p_RMSE | n_latih | n_uji | n_trials | detik_total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| earlystop | candle_1m | 1 | 80:20 | XGBoost | tpe | 348,918 | 616,306 | 0.024 | 56.998 | -0.103 | -3.179 | -0.148 | 0.8827 | -5.406 | 0.0 | 8,062 | 2,016 | 30 | 199.4 |
| earlystop | candle_1m | 1 | 80:20 | LightGBM | tpe | 349,492 | 636,547 | 0.024 | 49.522 | 0.061 | 0.001 | 11.09 | 0.0 | 0.332 | 0.7403 | 8,062 | 2,016 | 30 | 20.0 |
| earlystop | candle_1m | 1 | 80:20 | CatBoost | tpe | 349,435 | 615,764 | 0.024 | 57.057 | 0.045 | -3.264 | 0.06 | 0.9525 | -4.801 | 0.0 | 8,062 | 2,016 | 30 | 343.5 |
| earlystop | candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 91.5 |
| topk15 | candle_1m | 1 | 80:20 | XGBoost | tpe | 350,377 | 615,828 | 0.024 | 57.955 | 0.315 | -3.254 | 0.393 | 0.6942 | -4.963 | 0.0 | 8,062 | 2,016 | 30 | 5.9 |
| topk15 | candle_1m | 1 | 80:20 | LightGBM | tpe | 348,538 | 626,476 | 0.024 | 56.998 | -0.212 | -1.581 | -0.586 | 0.5577 | -6.309 | 0.0 | 8,062 | 2,016 | 30 | 29.1 |
| topk15 | candle_1m | 1 | 80:20 | CatBoost | tpe | 350,646 | 617,967 | 0.024 | 56.818 | 0.392 | -2.918 | 0.454 | 0.6498 | -3.766 | 0.0002 | 8,062 | 2,016 | 30 | 1054.3 |
| topk15 | candle_1m | 1 | 80:20 | AdaBoost | tpe | 350,082 | 636,008 | 0.024 | 53.828 | 0.23 | -0.084 | 6.51 | 0.0 | -3.222 | 0.0013 | 8,062 | 2,016 | 30 | 23.8 |
| lossl1 | candle_1m | 1 | 80:20 | XGBoost | tpe | 350,090 | 636,565 | 0.024 | 49.522 | 0.232 | 0.004 | 13.867 | 0.0 | 0.398 | 0.6904 | 8,062 | 2,016 | 30 | 3.8 |
| lossl1 | candle_1m | 1 | 80:20 | LightGBM | tpe | 346,752 | 626,176 | 0.023 | 58.732 | -0.723 | -1.628 | -2.133 | 0.0331 | -5.325 | 0.0 | 8,062 | 2,016 | 30 | 14.5 |
| lossl1 | candle_1m | 1 | 80:20 | CatBoost | tpe | 347,665 | 627,691 | 0.024 | 57.117 | -0.462 | -1.39 | -1.541 | 0.1235 | -4.653 | 0.0 | 8,062 | 2,016 | 30 | 54.8 |
| lossl1 | candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 90.5 |
| prunermedian | candle_1m | 1 | 80:20 | XGBoost | tpe | 347,969 | 625,011 | 0.024 | 58.373 | -0.375 | -1.811 | -1.221 | 0.2222 | -6.235 | 0.0 | 8,062 | 2,016 | 30 | 15.4 |
| prunermedian | candle_1m | 1 | 80:20 | LightGBM | tpe | 348,857 | 629,179 | 0.024 | 54.904 | -0.121 | -1.156 | -0.576 | 0.5645 | -6.903 | 0.0 | 8,062 | 2,016 | 30 | 3.4 |
| prunermedian | candle_1m | 1 | 80:20 | CatBoost | tpe | 348,066 | 622,845 | 0.024 | 56.818 | -0.347 | -2.151 | -0.85 | 0.3952 | -6.193 | 0.0 | 8,062 | 2,016 | 30 | 38.2 |
| prunermedian | candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 91.4 |

---

## 5. Baris Naive

| teknik | dataset | horizon_menit | split | MAE_Rp | RMSE_Rp | MAPE_pct | n_latih | n_uji |
|---|---|---|---|---|---|---|---|---|
| earlystop | candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 |
| topk15 | candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 |
| lossl1 | candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 |
| prunermedian | candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 |

Keempat baris Naive identik (MAE Rp349.278, RMSE Rp636.540) dan sama dengan baris
Naive `candle_1m` h1 80:20 di Tahap 1–3, karena pasangan, split, dan periodenya sama.
Naive tidak terpengaruh pengaturan `--early-stop`, `--top-k`, `--loss`, maupun
`--pruner`.

---

## 6. Selisih tiap teknik terhadap pembanding Tahap 2 (`tpe`)

Pembanding (`tahap2`, `tpe`, 42 fitur, `loss` l2, tanpa early stopping, tanpa pruner):

| model | MAE_Rp | MAE_vs_naive_pct | RMSE_vs_naive_pct | Akurasi arah (%) | p_MAE | detik |
|---|---|---|---|---|---|---|
| XGBoost | 348.262 | -0.291 | -2.765 | 57.476 | 0.5848 | 63,4 |
| LightGBM | 348.157 | -0.321 | -1.687 | 56.699 | 0.2964 | 4,8 |
| CatBoost | 348.066 | -0.347 | -2.151 | 56.818 | 0.3952 | 70,1 |
| AdaBoost | 349.047 | -0.066 | -2.058 | 54.426 | 0.8966 | 94,3 |
| **rata-rata** | | **-0.2563** | **-2.1655** | **56.355** | | **232,6** |

Kolom `Δ` di bawah = nilai teknik **minus** nilai pembanding. `Δ` negatif pada
`MAE_vs_naive_pct` berarti teknik itu memperbaiki (MAE turun relatif terhadap Naive).

### 6a. `--early-stop`

| model | MAE_vs_naive_pct | Δ | RMSE_vs_naive_pct | Δ | arah (%) | Δ | DM_MAE | p_MAE | detik |
|---|---|---|---|---|---|---|---|---|---|
| XGBoost | -0.103 | +0.188 | -3.179 | -0.414 | 57.00 | -0.48 | -0.148 | 0.8827 | 199,4 |
| LightGBM | 0.061 | +0.382 | 0.001 | +1.688 | 49.52 | -7.18 | **+11.090** | **0.0000** | 20,0 |
| CatBoost | 0.045 | +0.392 | -3.264 | -1.112 | 57.06 | +0.24 | 0.060 | 0.9525 | 343,5 |
| AdaBoost | -0.066 | 0.000 | -2.058 | 0.000 | 54.43 | 0.00 | -0.130 | 0.8966 | 91,5 |
| **rata-rata** | **-0.0158** | **+0.2405** | | | | | | | **654,5** |

Rata-rata `MAE_vs_naive_pct` memburuk 0,2405 poin persen. Waktu naik dari 232,6 s
ke 654,5 s (2,8×).

### 6b. `--top-k 15`

| model | MAE_vs_naive_pct | Δ | RMSE_vs_naive_pct | Δ | arah (%) | Δ | DM_MAE | p_MAE | detik |
|---|---|---|---|---|---|---|---|---|---|
| XGBoost | 0.315 | +0.606 | -3.254 | -0.489 | 57.95 | +0.48 | 0.393 | 0.6942 | 5,9 |
| LightGBM | -0.212 | +0.109 | -1.581 | +0.106 | 57.00 | +0.30 | -0.586 | 0.5577 | 29,1 |
| CatBoost | 0.392 | +0.738 | -2.918 | -0.766 | 56.82 | 0.00 | 0.454 | 0.6498 | 1.054,3 |
| AdaBoost | 0.230 | +0.296 | -0.084 | +1.975 | 53.83 | -0.60 | **+6.510** | **0.0000** | 23,8 |
| **rata-rata** | **+0.1811** | **+0.4374** | | | | | | | **1.113,2** |

Jumlah fitur turun 42 → 15. Rata-rata `MAE_vs_naive_pct` memburuk 0,4374 poin
persen — perubahan terbesar di antara keempat teknik. Waktu naik 4,8×.

### 6c. `--loss l1`

| model | MAE_vs_naive_pct | Δ | RMSE_vs_naive_pct | Δ | arah (%) | Δ | DM_MAE | p_MAE | detik |
|---|---|---|---|---|---|---|---|---|---|
| XGBoost | 0.232 | +0.523 | 0.004 | +2.769 | 49.52 | -7.95 | **+13.867** | **0.0000** | 3,8 |
| LightGBM | **-0.723** | **-0.402** | -1.628 | +0.059 | **58.73** | +2.03 | **-2.133** | **0.0331** | 14,5 |
| CatBoost | -0.462 | -0.115 | -1.390 | +0.761 | 57.12 | +0.30 | -1.541 | 0.1235 | 54,8 |
| AdaBoost | -0.066 | 0.000 | -2.058 | 0.000 | 54.43 | 0.00 | -0.130 | 0.8966 | 90,5 |
| **rata-rata** | **-0.2547** | **+0.0016** | | | | | | | **163,5** |

Rata-rata praktis tidak berubah (+0,0016), tetapi sebarannya melebar: LightGBM dan
CatBoost membaik, XGBoost memburuk tajam. Waktu turun dari 232,6 s ke 163,5 s.
**Run LightGBM di sini adalah satu-satunya run di seluruh eksperimen yang memenuhi
definisi "signifikan lebih baik dari Naive"** — lihat catatan teknis nomor 1.

### 6d. `--pruner median`

| model | MAE_vs_naive_pct | Δ | RMSE_vs_naive_pct | Δ | arah (%) | Δ | DM_MAE | p_MAE | n_pruned | detik |
|---|---|---|---|---|---|---|---|---|---|---|
| XGBoost | -0.375 | -0.084 | -1.811 | +0.954 | 58.37 | +0.90 | -1.221 | 0.2222 | 18 | 15,4 |
| LightGBM | -0.121 | +0.200 | -1.156 | +0.531 | 54.90 | -1.79 | -0.576 | 0.5645 | 9 | 3,4 |
| CatBoost | -0.347 | 0.000 | -2.151 | 0.000 | 56.82 | 0.00 | -0.850 | 0.3952 | 13 | 38,2 |
| AdaBoost | -0.066 | 0.000 | -2.058 | 0.000 | 54.43 | 0.00 | -0.130 | 0.8966 | 16 | 91,4 |
| **rata-rata** | **-0.2271** | **+0.0292** | | | | | | | **14** | **148,4** |

Rata-rata memburuk tipis (+0,0292) sementara waktu turun dari 232,6 s ke 148,4 s
(36% lebih cepat). CatBoost dan AdaBoost menghasilkan angka identik dengan
pembanding meskipun 13 dan 16 trial dipangkas.

### 6e. Ringkasan keempat teknik

| teknik | rata-rata `MAE_vs_naive_pct` | Δ vs Tahap 2 | total detik | Δ waktu | run signifikan lebih baik | run signifikan lebih buruk |
|---|---|---|---|---|---|---|
| pembanding (Tahap 2 `tpe`) | -0.2563 | — | 232,6 | — | 0 dari 4 | 0 dari 4 |
| `--loss l1` | -0.2547 | +0.0016 | 163,5 | -30% | **1 dari 4** | 1 dari 4 |
| `--pruner median` | -0.2271 | +0.0292 | 148,4 | -36% | 0 dari 4 | 0 dari 4 |
| `--early-stop` | -0.0158 | +0.2405 | 654,5 | +181% | 0 dari 4 | 1 dari 4 |
| `--top-k 15` | +0.1811 | +0.4374 | 1.113,2 | +378% | 0 dari 4 | 1 dari 4 |

---

## 7. Hyperparameter terbaik per teknik

Semua: `candle_1m`, harga `typical`, horizon 1 menit, split 80:20, `tpe`, 30 trial,
5 fold. Nilai di bawah dibaca langsung dari berkas JSON di `hasil/params/`.

### `--early-stop`

| model | n_fitur | hyperparameter terbaik |
|---|---|---|
| XGBoost | 42 | `n_estimators` 1725, `max_depth` 5, `learning_rate` 0.0011597, `min_child_weight` 28, `subsample` 0.828502, `colsample_bytree` 0.685392, `reg_lambda` 0.0074322, `reg_alpha` 0.00532279 |
| LightGBM | 42 | `n_estimators` 1, `num_leaves` 53, `max_depth` 6, `learning_rate` 0.0304053, `min_child_samples` 9, `subsample` 0.577997, `colsample_bytree` 0.340659, `reg_lambda` 21.423, `reg_alpha` 0.253782, `subsample_freq` 1 |
| CatBoost | 42 | `iterations` 1686, `depth` 8, `learning_rate` 0.00120994, `l2_leaf_reg` 0.14542, `random_strength` 0.371873, `bagging_temperature` 0.471673 |
| AdaBoost | 42 | `n_estimators` 32, `learning_rate` 0.00196343, `loss` linear, `max_depth` 3 |

Nilai `n_estimators` / `iterations` pada XGBoost, LightGBM, dan CatBoost di sini
**bukan** hasil tuning langsung: `optim.py` menetapkannya dari rata-rata jumlah
pohon terbaik yang ditemukan early stopping di kelima fold CV (ruang pencarian
dipatok ke `ES_MAX_TREES` = 2000 selama tuning). AdaBoost tidak memakai early
stopping.

### `--top-k 15`

| model | n_fitur | hyperparameter terbaik |
|---|---|---|
| XGBoost | 15 | `n_estimators` 116, `max_depth` 7, `learning_rate` 0.0642549, `min_child_weight` 25, `subsample` 0.940564, `colsample_bytree` 0.63424, `reg_lambda` 0.130988, `reg_alpha` 0.00538099 |
| LightGBM | 15 | `n_estimators` 20, `num_leaves` 5, `max_depth` 7, `learning_rate` 0.0369165, `min_child_samples` 80, `subsample` 0.580622, `colsample_bytree` 0.94475, `reg_lambda` 2.32446, `reg_alpha` 0.00950743, `subsample_freq` 1 |
| CatBoost | 15 | `iterations` 163, `depth` 5, `learning_rate` 0.0341698, `l2_leaf_reg` 18.5421, `random_strength` 0.0296133, `bagging_temperature` 0.91934 |
| AdaBoost | 15 | `n_estimators` 18, `learning_rate` 0.0693784, `loss` exponential, `max_depth` 1 |

### `--loss l1`

| model | n_fitur | hyperparameter terbaik |
|---|---|---|
| XGBoost | 42 | `n_estimators` 27, `max_depth` 4, `learning_rate` 0.239063, `min_child_weight` 8, `subsample` 0.985429, `colsample_bytree` 0.841396, `reg_lambda` 0.0680436, `reg_alpha` 0.00212918 |
| LightGBM | 42 | `n_estimators` 38, `num_leaves` 23, `max_depth` 8, `learning_rate` 0.0560859, `min_child_samples` 112, `subsample` 0.942933, `colsample_bytree` 0.87423, `reg_lambda` 0.00690816, `reg_alpha` 0.0127954, `subsample_freq` 1 |
| CatBoost | 42 | `iterations` 230, `depth` 7, `learning_rate` 0.00748232, `l2_leaf_reg` 2.68723, `random_strength` 0.00917637, `bagging_temperature` 0.290203 |
| AdaBoost | 42 | `n_estimators` 32, `learning_rate` 0.00196343, `loss` linear, `max_depth` 3 |

### `--pruner median`

| model | n_fitur | hyperparameter terbaik |
|---|---|---|
| XGBoost | 42 | `n_estimators` 293, `max_depth` 5, `learning_rate` 0.00207955, `min_child_weight` 29, `subsample` 0.945568, `colsample_bytree` 0.497968, `reg_lambda` 0.00311032, `reg_alpha` 0.00223894 |
| LightGBM | 42 | `n_estimators` 17, `num_leaves` 29, `max_depth` 8, `learning_rate` 0.0143726, `min_child_samples` 86, `subsample` 0.501433, `colsample_bytree` 0.994018, `reg_lambda` 3.22549, `reg_alpha` 0.00178866, `subsample_freq` 1 |
| CatBoost | 42 | `iterations` 420, `depth` 8, `learning_rate` 0.00161386, `l2_leaf_reg` 0.10368, `random_strength` 1.18432, `bagging_temperature` 0.567786 |
| AdaBoost | 42 | `n_estimators` 32, `learning_rate` 0.00196343, `loss` linear, `max_depth` 3 |

---

## 8. Catatan teknis

1. **Satu run signifikan lebih baik daripada Naive — pertama di seluruh eksperimen.**
   `--loss l1` + LightGBM: `MAE_vs_naive_pct` **-0,723186**, `DM_MAE` **-2,132559**,
   `p_MAE` **0,033082**. Ketiga syarat definisi terkunci terpenuhi bersamaan
   (`MAE_vs_naive_pct < 0`, `DM_MAE < 0`, `p_MAE < 0,05`). Run ini juga memiliki
   akurasi arah tertinggi di seluruh eksperimen (58,732%), `RMSE_vs_naive_pct`
   -1,628% dengan `p_RMSE` 1,13e-07, dan `std_pred_return` 3,66e-05 (tidak konstan).
   Dari 92 run model di seluruh Tahap 1–4, **ini satu-satunya** yang memenuhi
   definisi tersebut.

2. **Dua run menghasilkan prediksi konstan dan signifikan lebih buruk daripada
   Naive.** `--early-stop` + LightGBM: `std_pred_return` 1,06e-22, akurasi arah
   49,52%, `DM_MAE` +11,090, `p_MAE` 0,0000 — jumlah pohon akhirnya ditetapkan
   `n_estimators` = 1 dari rata-rata pohon terbaik CV, yaitu satu pohon tunggal.
   `--loss l1` + XGBoost: `std_pred_return` 1,14e-13, akurasi arah 49,52%,
   `DM_MAE` +13,867, `p_MAE` 0,0000 — di sini hyperparameternya
   (`n_estimators` 27, `max_depth` 4, `learning_rate` 0,239063) **bukan** setelan
   ekstrem, sehingga keadaan konstan itu tidak dapat dijelaskan dari
   hyperparameter saja; objektif `reg:absoluteerror` membuat prediksi dasar berupa
   median return, dan tidak ada split yang memperbaiki MAE di atas median itu.
   Pada kedua run akurasi arahnya sama (49,52%), konsisten dengan prediksi yang
   tidak pernah berubah tanda.

3. **AdaBoost tidak terpengaruh `--early-stop` maupun `--loss l1`.** Angkanya
   identik dengan pembanding Tahap 2 sampai digit terakhir (MAE Rp349.047,010432)
   pada ketiga tag `tahap4_earlystop`, `tahap4_lossl1`, dan `tahap4_prunermedian`.
   Ini sesuai README bagian 6 nomor 7: AdaBoost.R2 memakai parameter `loss`-nya
   sendiri yang sudah ikut dituning, dan early stopping tidak diterapkan padanya.

4. **`--pruner median` memangkas trial tetapi `n_trials` tetap 30.** Jumlah
   dipangkas: XGBoost 18, LightGBM 9, CatBoost 13, AdaBoost 16 (rata-rata 14 dari
   30). CatBoost dan AdaBoost tetap menemukan hyperparameter yang identik dengan
   pembanding, sehingga metriknya sama persis; XGBoost dan LightGBM berbeda.

5. **Pemangkasan pada AdaBoost terjadi setelah seluruh fold dihitung.** Di
   `btcpred/optim.py`, cabang AdaBoost menjalankan kelima fold secara paralel lalu
   baru memanggil `trial.report`/`should_prune`, sehingga 16 trial tercatat dipangkas
   tetapi waktunya hampir tidak berubah (91,4 s vs 94,3 s pembanding). Pada model
   lain pemangkasan terjadi di tengah fold dan memang memotong waktu (XGBoost
   63,4 s → 15,4 s).

6. **`--top-k 15` + CatBoost adalah run terlama di seluruh eksperimen**: 1.054,3
   detik (17,6 menit), yang 1.053,6 detik di antaranya adalah tuning. Hyperparameter
   akhirnya justru kecil (`iterations` 163, `depth` 5), jadi waktu itu dihabiskan
   oleh trial-trial lain sepanjang pencarian, bukan oleh model final. Seleksi fitur
   memperkecil data (42 → 15 kolom) tetapi tidak memperpendek waktu tuning.

7. **`--early-stop` mendorong jumlah pohon sangat besar pada dua model**: XGBoost
   `n_estimators` 1.725 dan CatBoost `iterations` 1.686, keduanya hasil rata-rata
   pohon terbaik CV dengan patokan maksimum 2.000. Waktunya ikut naik — CatBoost
   343,5 detik (4,9× pembanding) dan XGBoost 199,4 detik (3,1× pembanding).
   LightGBM bergerak ke arah berlawanan (`n_estimators` 1) dan menjadi run
   berprediksi konstan di catatan nomor 2.

8. **`RMSE_vs_naive_pct` tetap negatif pada 14 dari 16 run.** Dua pengecualian
   adalah dua run berprediksi konstan di catatan nomor 2 (`--early-stop` LightGBM
   +0,001%; `--loss l1` XGBoost +0,004%). Pola "RMSE menang, MAE tidak" yang muncul
   sejak Tahap 1 berlanjut di sini.

9. **`ringkas.py` menimpa berkas ringkasan.** Keluaran CSV tiap tag sudah
   diarsipkan ke `hasil/ringkasan/tahap4_earlystop/`, `tahap4_topk15/`,
   `tahap4_lossl1/`, dan `tahap4_prunermedian/`. Penataan berkas saja; tidak ada
   perubahan kode.

---

## 9. Berkas yang dihasilkan Tahap 4

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | bertambah 20 baris bertag `tahap4_*` (16 run model + 4 Naive); total 109 baris |
| `hasil/laporan/LAPORAN_TAHAP4.md` | laporan ini |
| `hasil/laporan/tahap4_<nama>_ringkasan.txt` | 4 berkas, keluaran `ringkas.py` per tag |
| `hasil/laporan/tahap4_<nama>_stdout.txt` | 4 berkas, keluaran mentah `run.py` |
| `hasil/laporan/tahap4_waktu.txt` | waktu mulai/selesai keempat teknik |
| `hasil/ringkasan/tahap4_<nama>/` | 4 folder arsip CSV ringkasan |
| `hasil/params/` | bertambah 16 berkas JSON (total 92) |
| `hasil/prediksi/` | bertambah 16 berkas CSV (total 92) |
