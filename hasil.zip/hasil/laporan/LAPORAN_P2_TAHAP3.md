# LAPORAN PERCOBAAN 2 (P2) — TAHAP 3: RASIO PEMBAGIAN DATA

**Dijalankan:** 2026-11-11, 02:00–02:09 WIB (8,3 menit) | **Tag:** `p2_tahap3`  
**Pasangan:** `ticker_5m`, horizon 60 menit | **Periode:** 2026-10-10 00:00 s.d. 2026-11-10 16:00 UTC  
**Metode optimasi:** `cmaes` **dan** `tpe` (dua metode, atas permintaan Ferdi)  
**Jumlah run:** 24 run model (3 rasio × 2 metode × 4 model) + 3 baris Naive, semua selesai

> **Penyimpangan dari aturan terkunci.** `KEPUTUSAN_TERKUNCI.md` mematok Tahap 3 memakai satu metode terpilih (`cmaes`). Atas permintaan Ferdi, `tpe` dijalankan sekalian supaya perbandingan lebih kaya. Penyimpangan ini disengaja dan dicatat; `cmaes` tetap metode resmi hasil Tahap 2.

---

## 1. Komposisi tiap rasio

| split | MAE_Rp | n_latih | n_uji | uji_mulai |
|---|---|---|---|---|
| 80:20 | 3545674.000 | 7275 | 1822 | 2026-11-04 07:15:00 |
| 70:30 | 3377162.000 | 6364 | 2733 | 2026-11-01 03:20:00 |
| 60:40 | 3462906.000 | 5453 | 3644 | 2026-10-28 23:25:00 |

Pembagian berurutan waktu, dengan *purging* 12 bar (= horizon 60 menit) di ujung data latih. Semua rasio berakhir di titik yang sama (2026-11-10 15:00); yang berbeda adalah **kapan periode uji mulai**.

## 2. MAE vs Naive (%) — negatif = lebih akurat dari Naive

| split | optimasi | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| 60:40 | cmaes | -0.006 | -0.006 | 0.011 | 5.863 |
| 60:40 | tpe | -0.006 | -0.008 | -0.001 | 2.476 |
| 70:30 | cmaes | -0.068 | -0.161 | -0.167 | 2.072 |
| 70:30 | tpe | 0.008 | -0.070 | -0.201 | -0.628 |
| 80:20 | cmaes | -0.251 | -0.140 | -0.284 | -0.749 |
| 80:20 | tpe | -0.284 | -0.221 | -0.330 | 1.186 |

## 3. p-value Diebold-Mariano (p_MAE)

| split | optimasi | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| 60:40 | cmaes | 0.176 | 0.582 | 0.963 | 0.002 |
| 60:40 | tpe | 0.176 | 0.133 | 0.994 | 0.076 |
| 70:30 | cmaes | 0.738 | 0.458 | 0.430 | 0.152 |
| 70:30 | tpe | 0.975 | 0.757 | 0.413 | 0.321 |
| 80:20 | cmaes | 0.429 | 0.462 | 0.176 | 0.380 |
| 80:20 | tpe | 0.422 | 0.361 | 0.137 | 0.352 |

## 4. Akurasi arah (%)

| split | optimasi | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| 60:40 | cmaes | 54.000 | 53.100 | 53.000 | 54.100 |
| 60:40 | tpe | 54.000 | 54.000 | 52.900 | 57.100 |
| 70:30 | cmaes | 53.500 | 55.200 | 55.100 | 54.200 |
| 70:30 | tpe | 54.800 | 54.600 | 54.600 | 55.800 |
| 80:20 | cmaes | 55.900 | 55.100 | 57.200 | 57.700 |
| 80:20 | tpe | 56.700 | 55.700 | 57.800 | 55.300 |

## 5. Temuan pokok

### 5a. Keunggulan atas Naive menyusut rapi seiring data latih mengecil

Rata-rata tiga model utama (AdaBoost dikeluarkan karena perilakunya liar, lihat 5c):

| rasio | data latih | cmaes | tpe |
|---|---|---|---|
| 80:20 | 7.275 bar (25,3 hari) | −0,225 | −0,279 |
| 70:30 | 6.364 bar (22,1 hari) | −0,132 | −0,088 |
| 60:40 | 5.453 bar (19,0 hari) | −0,000 | −0,005 |

Pola ini konsisten di kedua metode optimasi dan ketiga model. Akurasi arah bergerak searah: 55–58% di 80:20, turun ke 53–54% di 60:40. Jadi data latih yang lebih banyak memang menghasilkan model yang sedikit lebih berguna — tetapi keunggulannya tetap **tidak signifikan di semua rasio** (p_MAE terkecil 0,133).

### 5b. Di 60:40 model berhenti memprediksi — ia jadi Naive dengan pergeseran tetap

Ini temuan terpenting tahap ini, dan baru terlihat setelah file prediksi dibuka satu per satu. Sebaran prediksi return di data uji:

| run | jumlah nilai prediksi unik | rata-rata return prediksi | std |
|---|---|---|---|
| XGBoost 60:40 `cmaes` | **1** | −2,21e−06 | **0** |
| XGBoost 60:40 `tpe` | **1** | −2,21e−06 | **0** |
| LightGBM 80:20 `cmaes` | 3 | −7,45e−05 | 6,4e−17 |
| CatBoost 80:20 `tpe` | 414 | −6,43e−05 | 7,6e−05 |
| AdaBoost 80:20 `cmaes` | 42 | −9,23e−05 | 4,7e−04 |

XGBoost di 60:40 mengeluarkan **satu nilai yang sama untuk seluruh 3.644 baris uji**. Secara efektif modelnya adalah "harga akan bergeser −0,0002% dari sekarang, apa pun kondisinya" — nol kandungan informasi, hanya satu konstanta. Dengan data latih 19 hari, tuning menyimpulkan bahwa tidak memprediksi apa-apa adalah strategi terbaik, lalu memangkas model sampai rata (`max_depth` kecil + regularisasi besar). Angka −0,006% yang tampak "menang tipis" dari Naive itu bukan kemampuan prediksi.

LightGBM 80:20 `cmaes` kasusnya sama walau lebih halus: cuma 3 nilai unik, std 6e−17. Ini juga menjelaskan kenapa di Tahap 2 `cmaes` dan `ga` memberi angka LightGBM yang identik — keduanya jatuh ke solusi datar yang sama.

### 5c. Sebagian keunggulan atas Naive berasal dari tren turun, bukan prediksi

Harga BTC turun sepanjang semua periode uji:

| rasio | harga awal uji | harga akhir uji | total | rata-rata return per 60 menit |
|---|---|---|---|---|
| 80:20 | Rp1.413,6 jt | Rp1.324,8 jt | −6,49% | −4,25e−04 |
| 70:30 | Rp1.407,3 jt | Rp1.324,8 jt | −6,04% | −2,64e−04 |
| 60:40 | Rp1.475,1 jt | Rp1.324,8 jt | −10,75% | −3,53e−04 |

Semua model memprediksi return rata-rata **negatif** (−6e−05 s.d. −9e−05), searah tren. Naive selalu memprediksi nol. Jadi di pasar yang turun terus, menambahkan pergeseran negatif konstan saja sudah cukup untuk mengalahkan Naive sedikit — tanpa perlu tahu apa-apa soal waktu. Inilah mekanisme di balik angka −0,2% s.d. −0,3% di 80:20, bukan kemampuan menebak pergerakan.

Konsekuensinya untuk skripsi: keunggulan kecil yang terlihat **tidak boleh** ditafsirkan sebagai "model berhasil memprediksi harga". Kalau periode ujinya pasar naik, pergeseran negatif yang sama akan berbalik merugikan. Ini juga menjelaskan kenapa tidak ada yang signifikan — uji Diebold-Mariano memang tidak bisa dibohongi oleh keuntungan dari satu arah tren.

### 5d. AdaBoost tidak stabil dan harus diperlakukan terpisah

AdaBoost melompat-lompat tanpa pola: −0,749 (80:20 cmaes) → +1,186 (80:20 tpe) → +2,072 (70:30 cmaes) → −0,628 (70:30 tpe) → +5,863 (60:40 cmaes). Yang di 60:40 `cmaes` bahkan **signifikan lebih buruk** dari Naive (+5,863%, p = 0,002). Angka −0,749 di Tahap 2 yang jadi dasar terpilihnya `cmaes` tidak bertahan saat rasio digeser — menguatkan catatan Tahap 2 bahwa dasar pemilihan itu tipis.

### 5e. Nol dari 24 run signifikan lebih baik dari Naive

Konsisten dengan Tahap 1 P2 (0/36), Tahap 2 P2 (0/28), dan seluruh Percobaan 1. Yang signifikan hanya satu, dan arahnya lebih buruk.

## 6. Tidak ada pemilihan di tahap ini

Sesuai aturan terkunci, ketiga rasio dilaporkan apa adanya dan **80:20 tetap dipakai** untuk Tahap 4. MAE rupiah antar rasio tidak dibandingkan langsung karena periode ujinya berbeda (uji 60:40 mencakup akhir Oktober yang penurunannya lebih dalam), hanya `MAE_vs_naive_pct` di dalam rasio yang sama.

Catatan jujur: pola 5a bisa menggoda untuk dibaca "80:20 rasio terbaik". Itu bukan kesimpulan yang sah — periode ujinya beda, dan angka yang diperingkat semuanya tidak signifikan. Yang sah dikatakan: *keunggulan atas Naive mengecil ketika data latih dikurangi, dan di 19 hari model sudah tidak memprediksi apa pun.*

## 7. Perbandingan cmaes vs tpe

Untuk tiga model utama keduanya praktis sama (selisih rata-rata < 0,06 poin persen di setiap rasio, berganti-ganti unggul). Untuk AdaBoost keduanya sama-sama tidak bisa diandalkan. Menjalankan dua metode di tahap ini memperkuat kesimpulan Tahap 2: **pilihan metode optimasi tidak menentukan hasil**; yang menentukan adalah ada-tidaknya tuning dan banyaknya data latih.

## 8. Langkah berikutnya

Tahap 4 menguji empat teknik tambahan satu per satu di `ticker_5m` h60, split 80:20. Dengan dua metode sekalian:

```bash
python run.py --datasets ticker_5m --horizons 60 --optimizers cmaes tpe --splits 0.8 --early-stop --start "2026-10-10 00:00" --end "2026-11-10 16:00" --tag p2_tahap4_earlystop
# lalu --top-k 15 / --loss l1 / --pruner median dengan tag masing-masing
```

Satu saran yang layak dipertimbangkan sebelum Tahap 4: tambahkan pemeriksaan jumlah nilai prediksi unik ke `ringkas.py` atau laporan. Kolom `std_pred_return` sudah ada di `hasil_semua.csv` tetapi tidak pernah ditampilkan, padahal itu yang mengungkap model datar di 5b. Tanpa itu, run yang sebenarnya tidak memprediksi apa pun bisa lolos terbaca sebagai "menang tipis dari Naive".
