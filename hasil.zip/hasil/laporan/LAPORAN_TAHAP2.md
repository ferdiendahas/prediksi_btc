# LAPORAN TAHAP 2 — Membandingkan Metode Optimasi

**Eksperimen data satu minggu (14–20 Okt 2026).**
Dibuat 2026-10-27. Laporan faktual; tidak memuat interpretasi atau kesimpulan.

Pasangan yang dipakai berasal dari Tahap 1: **`candle_1m`, horizon 1 menit**,
split 80:20 (lihat `hasil/laporan/LAPORAN_TAHAP1.md` bagian 6).

---

## 1. Perintah persis yang dijalankan

```bash
source .venv/bin/activate
caffeinate -i python run.py --datasets candle_1m --horizons 1 --splits 0.8 \
  --optimizers default grid random tpe cmaes ga qmc --tag tahap2
python ringkas.py --tag tahap2 > hasil/laporan/tahap2_ringkasan.txt
```

Keluaran mentah di `hasil/laporan/tahap2_stdout.txt`. Pengaturan lain dari
`config.py`: `N_TRIALS` 30, `N_FOLDS` 5, `PRUNER` None, `EARLY_STOP` False,
`TOP_K` None, `LOSS` l2, `SEED` 42, periode 2026-10-14 00:00 s.d.
2026-10-20 23:59 UTC.

---

## 2. Waktu

| | |
|---|---|
| Mulai | 2026-10-27 17:49:47 WIB |
| Selesai | 2026-10-27 18:07:01 WIB |
| Durasi total (wall clock) | 17 menit 14 detik (17,2 menit) |
| Jumlah `detik_total` semua run | 1.030,6 detik |
| Jumlah `detik_tuning` semua run | 1.012,1 detik |
| Exit code | 0 |

---

## 3. Jumlah run

| | |
|---|---|
| Direncanakan (brief) | 28 (4 model × 7 metode) |
| Maksimum menurut `run.py` | 28 |
| Dilewati karena kombinasi tidak valid | 0 |
| Selesai | **28** |
| Gagal | **0** |

Tidak ada pesan error. Baris Naive yang dicatat: 1 (pasangan `candle_1m` h1
split 80:20 bertag `tahap2`). Total baris bertag `tahap2` di
`hasil/hasil_semua.csv`: 29.

Jumlah trial per metode: `default` 1, `grid` 27 (ditentukan jumlah kombinasi
grid 3×3×3), `random`/`tpe`/`cmaes`/`ga`/`qmc` masing-masing 30.
`n_pruned` = 0 pada semua run (pruner tidak aktif). Jumlah fitur: 42.

---

## 4. Tabel lengkap semua run Tahap 2

Persen dibulatkan 3 desimal, rupiah bilangan bulat, p-value 4 desimal.
`MAE_vs_naive_pct` negatif = MAE lebih kecil daripada Naive.
`DM_MAE` negatif = model lebih akurat daripada Naive pada loss absolut.

| dataset | horizon_menit | split | model | optimasi | MAE_Rp | RMSE_Rp | MAPE_pct | Akurasi_arah_pct | MAE_vs_naive_pct | RMSE_vs_naive_pct | DM_MAE | p_MAE | DM_RMSE | p_RMSE | n_latih | n_uji | n_trials | detik_total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | AdaBoost | default | 398,893 | 653,471 | 0.027 | 51.854 | 14.205 | 2.66 | 13.533 | 0.0 | 4.334 | 0.0 | 8,062 | 2,016 | 1 | 3.0 |
| candle_1m | 1 | 80:20 | AdaBoost | grid | 350,746 | 632,446 | 0.024 | 53.409 | 0.42 | -0.643 | 2.751 | 0.006 | -5.644 | 0.0 | 8,062 | 2,016 | 27 | 116.9 |
| candle_1m | 1 | 80:20 | AdaBoost | random | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 71.0 |
| candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 94.3 |
| candle_1m | 1 | 80:20 | AdaBoost | cmaes | 351,849 | 631,538 | 0.024 | 53.23 | 0.736 | -0.786 | 3.754 | 0.0002 | -5.294 | 0.0 | 8,062 | 2,016 | 30 | 85.0 |
| candle_1m | 1 | 80:20 | AdaBoost | ga | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 111.1 |
| candle_1m | 1 | 80:20 | AdaBoost | qmc | 350,857 | 635,663 | 0.024 | 53.409 | 0.452 | -0.138 | 7.706 | 0.0 | -3.334 | 0.0009 | 8,062 | 2,016 | 30 | 108.4 |
| candle_1m | 1 | 80:20 | CatBoost | default | 387,051 | 631,596 | 0.026 | 55.801 | 10.815 | -0.777 | 7.386 | 0.0 | -0.654 | 0.513 | 8,062 | 2,016 | 1 | 6.2 |
| candle_1m | 1 | 80:20 | CatBoost | grid | 348,228 | 625,438 | 0.024 | 56.4 | -0.301 | -1.744 | -0.95 | 0.3422 | -6.577 | 0.0 | 8,062 | 2,016 | 27 | 21.3 |
| candle_1m | 1 | 80:20 | CatBoost | random | 348,489 | 627,695 | 0.024 | 55.383 | -0.226 | -1.39 | -0.891 | 0.3733 | -5.349 | 0.0 | 8,062 | 2,016 | 30 | 23.1 |
| candle_1m | 1 | 80:20 | CatBoost | tpe | 348,066 | 622,845 | 0.024 | 56.818 | -0.347 | -2.151 | -0.85 | 0.3952 | -6.193 | 0.0 | 8,062 | 2,016 | 30 | 70.1 |
| candle_1m | 1 | 80:20 | CatBoost | cmaes | 348,088 | 624,490 | 0.024 | 55.921 | -0.341 | -1.893 | -0.935 | 0.3499 | -6.117 | 0.0 | 8,062 | 2,016 | 30 | 21.7 |
| candle_1m | 1 | 80:20 | CatBoost | ga | 348,489 | 627,695 | 0.024 | 55.383 | -0.226 | -1.39 | -0.891 | 0.3733 | -5.349 | 0.0 | 8,062 | 2,016 | 30 | 17.1 |
| candle_1m | 1 | 80:20 | CatBoost | qmc | 348,476 | 627,140 | 0.024 | 58.313 | -0.23 | -1.477 | -0.906 | 0.3649 | -7.141 | 0.0 | 8,062 | 2,016 | 30 | 25.8 |
| candle_1m | 1 | 80:20 | LightGBM | default | 372,283 | 621,637 | 0.025 | 57.057 | 6.586 | -2.341 | 4.733 | 0.0 | -1.838 | 0.0662 | 8,062 | 2,016 | 1 | 2.1 |
| candle_1m | 1 | 80:20 | LightGBM | grid | 349,137 | 634,318 | 0.024 | 55.203 | -0.041 | -0.349 | -0.657 | 0.5115 | -6.246 | 0.0 | 8,062 | 2,016 | 27 | 65.7 |
| candle_1m | 1 | 80:20 | LightGBM | random | 347,570 | 618,852 | 0.024 | 57.117 | -0.489 | -2.779 | -0.859 | 0.3902 | -5.199 | 0.0 | 8,062 | 2,016 | 30 | 17.1 |
| candle_1m | 1 | 80:20 | LightGBM | tpe | 348,157 | 625,799 | 0.024 | 56.699 | -0.321 | -1.687 | -1.044 | 0.2964 | -6.32 | 0.0 | 8,062 | 2,016 | 30 | 4.8 |
| candle_1m | 1 | 80:20 | LightGBM | cmaes | 349,445 | 634,710 | 0.024 | 56.519 | 0.048 | -0.288 | 0.893 | 0.3721 | -7.784 | 0.0 | 8,062 | 2,016 | 30 | 11.0 |
| candle_1m | 1 | 80:20 | LightGBM | ga | 349,348 | 633,926 | 0.024 | 55.801 | 0.02 | -0.411 | 0.249 | 0.8037 | -7.05 | 0.0 | 8,062 | 2,016 | 30 | 6.6 |
| candle_1m | 1 | 80:20 | LightGBM | qmc | 348,041 | 624,770 | 0.024 | 56.28 | -0.354 | -1.849 | -1.005 | 0.3148 | -6.798 | 0.0 | 8,062 | 2,016 | 30 | 11.9 |
| candle_1m | 1 | 80:20 | XGBoost | default | 364,264 | 625,121 | 0.025 | 56.459 | 4.291 | -1.794 | 3.817 | 0.0001 | -1.777 | 0.0758 | 8,062 | 2,016 | 1 | 0.3 |
| candle_1m | 1 | 80:20 | XGBoost | grid | 349,486 | 635,509 | 0.024 | 55.323 | 0.059 | -0.162 | 1.894 | 0.0583 | -7.401 | 0.0 | 8,062 | 2,016 | 27 | 25.8 |
| candle_1m | 1 | 80:20 | XGBoost | random | 349,520 | 617,572 | 0.024 | 56.16 | 0.069 | -2.98 | 0.102 | 0.919 | -4.994 | 0.0 | 8,062 | 2,016 | 30 | 11.4 |
| candle_1m | 1 | 80:20 | XGBoost | tpe | 348,262 | 618,940 | 0.024 | 57.476 | -0.291 | -2.765 | -0.546 | 0.5848 | -6.128 | 0.0 | 8,062 | 2,016 | 30 | 63.4 |
| candle_1m | 1 | 80:20 | XGBoost | cmaes | 350,170 | 615,488 | 0.024 | 58.014 | 0.255 | -3.307 | 0.313 | 0.7544 | -4.871 | 0.0 | 8,062 | 2,016 | 30 | 14.0 |
| candle_1m | 1 | 80:20 | XGBoost | ga | 348,788 | 622,190 | 0.024 | 57.715 | -0.14 | -2.254 | -0.334 | 0.7382 | -5.745 | 0.0 | 8,062 | 2,016 | 30 | 7.1 |
| candle_1m | 1 | 80:20 | XGBoost | qmc | 348,029 | 628,544 | 0.024 | 57.237 | -0.358 | -1.256 | -1.726 | 0.0845 | -7.193 | 0.0 | 8,062 | 2,016 | 30 | 14.4 |

---

## 5. Baris Naive

| dataset | horizon_menit | split | MAE_Rp | RMSE_Rp | MAPE_pct | n_latih | n_uji | uji_mulai | uji_akhir |
|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 | 2026-10-19 14:23:00 | 2026-10-20 23:58:00 |

Nilai Naive identik dengan baris Naive `candle_1m` h1 80:20 di Tahap 1
(MAE Rp349.278, RMSE Rp636.540), karena pasangan, split, dan periodenya sama.

---

## 6. Penerapan aturan pemilihan (bagian 4 brief)

Aturan Tahap 2, apa adanya dari `hasil/KEPUTUSAN_TERKUNCI.md`:

> **Aturan memilih metode optimasi untuk tahap 3 dan 4:** rata-rata
> `MAE_vs_naive_pct` keempat model paling kecil. Kalau seri, pilih yang waktu
> tuning totalnya paling singkat. `default` tidak boleh dipilih (fungsinya
> sebagai pembanding tanpa tuning).

### Langkah 1 — hitung rata-rata `MAE_vs_naive_pct` keempat model per metode

| metode | XGBoost | LightGBM | CatBoost | AdaBoost | **rata-rata** | total `detik_tuning` |
|---|---|---|---|---|---|---|
| `tpe` | -0.291 | -0.321 | -0.347 | -0.066 | **-0.2563** | 229,3 s |
| `random` | 0.069 | -0.489 | -0.226 | -0.066 | -0.1780 | 118,7 s |
| `qmc` | -0.358 | -0.354 | -0.230 | 0.452 | -0.1225 | 157,4 s |
| `ga` | -0.140 | 0.020 | -0.226 | -0.066 | -0.1032 | 140,0 s |
| `grid` | 0.059 | -0.041 | -0.301 | 0.420 | 0.0346 | 227,6 s |
| `cmaes` | 0.255 | 0.048 | -0.341 | 0.736 | 0.1746 | 129,9 s |
| `default` | 4.291 | 6.586 | 10.815 | 14.205 | 8.9741 | 9,2 s |

### Langkah 2 — buang `default`

`default` memiliki rata-rata terbesar (8,9741) dan menurut aturan memang tidak
boleh dipilih. Dikeluarkan dari pertimbangan.

### Langkah 3 — ambil rata-rata terkecil

Rata-rata terkecil di antara enam metode yang tersisa adalah **`tpe`**
dengan **-0.2563**. Selisih ke peringkat dua (`random`, -0.1780) adalah
0,0783 poin persen.

### Langkah 4 — cek seri

Nilai -0.2563 hanya dimiliki satu metode. **Aturan penyelesaian seri (waktu
tuning terpendek) tidak perlu dipakai.** Dicatat sebagai fakta: seandainya
aturan seri terpakai, `tpe` justru metode dengan waktu tuning terpanjang
(229,3 detik).

### Pilihan akhir Tahap 2

| | |
|---|---|
| Metode optimasi terpilih | **`tpe`** (Bayesian Optimization / Tree-structured Parzen Estimator) |
| Rata-rata `MAE_vs_naive_pct` | -0.2563 |
| Total `detik_tuning` | 229,3 detik |
| Dipakai untuk | Tahap 3 dan Tahap 4 |

Perintah Tahap 3 dan Tahap 4 yang mengikuti pilihan ini:

```bash
# Tahap 3
python run.py --datasets candle_1m --horizons 1 --optimizers tpe \
  --splits 0.8 0.7 0.6 --tag tahap3

# Tahap 4
python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --early-stop     --tag tahap4_earlystop
python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --top-k 15       --tag tahap4_topk15
python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --loss l1        --tag tahap4_lossl1
python run.py --datasets candle_1m --horizons 1 --optimizers tpe --splits 0.8 --pruner median  --tag tahap4_prunermedian
```

### Status signifikansi

Memakai definisi terkunci (`MAE_vs_naive_pct < 0` **dan** `DM_MAE < 0` **dan**
`p_MAE < 0.05`): **0 dari 28 run Tahap 2 signifikan lebih baik dari Naive.**
Run dengan `MAE_vs_naive_pct < 0` ada 15, `p_MAE` terkecil di antaranya adalah
0,0850 (XGBoost `qmc`). Aturan pemilihan Tahap 2 tidak memakai signifikansi,
jadi status ini tidak mengubah pilihan; dicatat sebagai fakta.

---

## 7. Hyperparameter terbaik untuk konfigurasi terpilih

Konfigurasi terpilih: `candle_1m`, harga `typical`, horizon 1 menit, split 80:20,
optimasi **`tpe`**, `loss` l2, tanpa early stopping, tanpa seleksi fitur, tanpa
pruner, 30 trial, 5 fold, 42 fitur. Sumber: `hasil/params/`.

| model | cv_mae_return | hyperparameter terbaik |
|---|---|---|
| XGBoost | 0.000223 | `n_estimators` 452, `max_depth` 7, `learning_rate` 0.0031346, `min_child_weight` 48, `subsample` 0.74621, `colsample_bytree` 0.55215, `reg_lambda` 0.30546, `reg_alpha` 0.0053916 |
| LightGBM | 0.000224 | `n_estimators` 27, `num_leaves` 25, `max_depth` 7, `learning_rate` 0.014728, `min_child_samples` 28, `subsample` 0.59400, `colsample_bytree` 0.92573, `reg_lambda` 4.22932, `reg_alpha` 0.0034210, `subsample_freq` 1 |
| CatBoost | 0.000224 | `iterations` 420, `depth` 8, `learning_rate` 0.0016139, `l2_leaf_reg` 0.10368, `random_strength` 1.18432, `bagging_temperature` 0.56779 |
| AdaBoost | 0.000224 | `n_estimators` 32, `learning_rate` 0.0019634, `loss` linear, `max_depth` 3 |

Hyperparameter ini **identik** dengan yang dilaporkan di Tahap 1 bagian 7, karena
konfigurasi, seed, dan data persis sama — lihat catatan teknis nomor 1.

---

## 8. Catatan teknis

1. **Reproduksibilitas terkonfirmasi.** Keempat run `tpe` di Tahap 2 menghasilkan
   angka yang identik sampai digit terakhir dengan run `tpe` yang sama di Tahap 1
   (XGBoost Rp348.261,539456; LightGBM Rp348.157,247281; CatBoost Rp348.066,370572;
   AdaBoost Rp349.047,010432), termasuk `cv_mae_return`. Ini sekaligus memverifikasi
   bahwa perbaikan `--tag` pada `run_id` (lihat `hasil/LOG_PERUBAHAN.md`) mencatat
   ulang run yang beririsan antar tahap tanpa mengubah nilainya.

2. **Tiga metode menghasilkan hasil identik pada AdaBoost.** `random`, `tpe`, dan
   `ga` sama persis untuk AdaBoost (MAE Rp349.047,010432; `MAE_vs_naive_pct`
   -0,066212; akurasi arah 54,426%), artinya ketiganya berhenti pada titik
   hyperparameter yang sama. Hal serupa terjadi pada CatBoost untuk `random` dan
   `ga` (MAE Rp348.489,309). Ini konsisten dengan catatan README bagian 6 nomor 5:
   metode berbasis acak memakai seed yang sama dan diawali trial acak yang sama.

3. **`default` terpaut jauh.** Rata-rata `MAE_vs_naive_pct` `default` adalah
   +8,9741 — dua orde lebih besar daripada metode bertuning mana pun, dengan
   `p_MAE` = 0,0000 pada keempat model (yaitu signifikan lebih **buruk** daripada
   Naive). Waktu tuningnya 9,2 detik karena hanya 1 evaluasi CV per model.

4. **`grid` memakai 27 trial, bukan 30.** Jumlah ini ditentukan oleh ukuran grid
   (3×3×3), sesuai README bagian 6 nomor 6. Perbandingan antar metode karena itu
   tidak sepenuhnya setara dalam jumlah evaluasi.

5. **Tidak ada run dengan prediksi konstan pada tahap ini.** `std_pred_return`
   terkecil adalah 3,0e-06 (XGBoost `grid`), diikuti 3,8e-06 (AdaBoost `qmc`) dan
   5,9e-06 (LightGBM `cmaes`). Tidak ada nilai nol atau orde 1e-21 seperti yang
   muncul di beberapa run Tahap 1.

6. **`p_RMSE` = 0,0000 pada hampir semua run bertuning**, dengan
   `RMSE_vs_naive_pct` antara -3,31% (XGBoost `cmaes`) dan -0,14% (AdaBoost `qmc`).
   Pengecualian: AdaBoost `default` dengan `RMSE_vs_naive_pct` +2,66%. Dicatat
   sebagai fakta; aturan pemilihan tetap memakai `MAE_vs_naive_pct`.

7. **Run paling lama**: AdaBoost `grid` 117,1 detik, AdaBoost `ga` 110,7 detik,
   AdaBoost `qmc` 107,8 detik, AdaBoost `tpe` 93,9 detik. Keempat run terlama
   seluruhnya AdaBoost, konsisten dengan README bagian 5.

8. **`ringkas.py` menimpa berkas ringkasan.** `ringkas.py` selalu menulis ke nama
   berkas yang sama di `hasil/ringkasan/`, sehingga menjalankannya untuk `tahap2`
   menimpa CSV hasil `tahap1`. Berkas sudah dibuat ulang dan diarsipkan ke
   `hasil/ringkasan/tahap1/` dan `hasil/ringkasan/tahap2/` dengan menyalin keluaran
   setelah tiap pemanggilan. Ini hanya penataan berkas; **tidak ada perubahan kode**
   dan tidak ada angka yang berubah. Laporan `.txt` per tahap tidak terpengaruh
   karena namanya memang sudah memuat nama tahap.

9. **Peringkat metode berbeda antar model.** Metode terbaik per model: XGBoost
   `qmc` (-0,358), LightGBM `random` (-0,489), CatBoost `tpe` (-0,347), AdaBoost
   `random`/`tpe`/`ga` (-0,066). Tidak ada satu metode pun yang terbaik untuk
   keempat model; `tpe` terpilih berdasarkan rata-rata, sesuai aturan.

---

## 9. Berkas yang dihasilkan Tahap 2

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | bertambah 29 baris bertag `tahap2` (28 run model + 1 Naive); total 74 baris |
| `hasil/laporan/LAPORAN_TAHAP2.md` | laporan ini |
| `hasil/laporan/tahap2_ringkasan.txt` | keluaran `ringkas.py --tag tahap2` |
| `hasil/laporan/tahap2_stdout.txt` | keluaran mentah `run.py` |
| `hasil/laporan/tahap2_waktu.txt` | waktu mulai dan selesai |
| `hasil/params/` | bertambah 28 berkas JSON |
| `hasil/prediksi/` | bertambah 28 berkas CSV |
| `hasil/ringkasan/` | keluaran `ringkas.py --tag tahap2` (4 CSV) |
| `hasil/ringkasan/tahap1/`, `hasil/ringkasan/tahap2/` | arsip per tahap — lihat catatan teknis nomor 8 |
