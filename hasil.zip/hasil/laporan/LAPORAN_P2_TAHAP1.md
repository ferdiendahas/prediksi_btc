# LAPORAN PERCOBAAN 2 (P2) — TAHAP 1: TIME FRAME

**Dijalankan:** 2026-11-11 | **Tag:** `p2_tahap1`  
**Periode:** 2026-10-10 00:00 s.d. 2026-11-10 16:00 UTC (±31,7 hari)  
**Data:** `btcidr_candle_1menit_20261110_1642.csv` (46.693 bar), `btcidr_ticker_5menit_20261110_1642.csv` (9.338 bar) — tidak ada bar hilang  
**Konfigurasi:** optimasi TPE, split 80:20, N_TRIALS 30, N_FOLDS 5, seed 42 — identik dengan Tahap 1 asli kecuali periode data  
**Jumlah run:** 36 run model + 9 baris Naive, semua selesai

> Status: **eksperimen tambahan**, bukan pengganti Tahap 1 resmi. `hasil/KEPUTUSAN_TERKUNCI.md` mengunci periode Tahap 1 pada 14–20 Okt 2026 dan tidak diubah.

---

## 1. Hasil utama: MAE vs Naive (%)

Negatif = lebih akurat dari Naive.

| dataset | horizon_menit | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| candle_1m | 1 | 0.837 | 0.095 | 0.632 | 0.621 |
| candle_1m | 5 | 0.181 | 0.122 | 0.311 | 0.640 |
| candle_1m | 15 | 0.067 | 0.078 | 0.028 | 0.030 |
| candle_1m | 30 | 0.042 | 0.042 | 0.040 | 0.012 |
| candle_1m | 60 | -0.231 | -0.137 | -0.181 | -0.166 |
| ticker_5m | 5 | 0.241 | 0.240 | 0.238 | 0.551 |
| ticker_5m | 15 | 0.133 | 0.099 | 0.090 | 0.272 |
| ticker_5m | 30 | 0.031 | 0.053 | -0.003 | 2.578 |
| ticker_5m | 60 | -0.284 | -0.221 | -0.330 | 1.186 |

## 2. p-value uji Diebold-Mariano (p_MAE)

Signifikan bila < 0,05.

| dataset | horizon_menit | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| candle_1m | 1 | 0.001 | 0.000 | 0.001 | 0.007 |
| candle_1m | 5 | 0.355 | 0.379 | 0.038 | 0.085 |
| candle_1m | 15 | 0.173 | 0.102 | 0.647 | 0.887 |
| candle_1m | 30 | 0.632 | 0.632 | 0.645 | 0.796 |
| candle_1m | 60 | 0.124 | 0.448 | 0.297 | 0.459 |
| ticker_5m | 5 | 0.000 | 0.000 | 0.000 | 0.000 |
| ticker_5m | 15 | 0.063 | 0.142 | 0.119 | 0.062 |
| ticker_5m | 30 | 0.742 | 0.771 | 0.978 | 0.138 |
| ticker_5m | 60 | 0.422 | 0.361 | 0.137 | 0.352 |

## 3. Temuan pokok

**Tidak ada satu pun model yang signifikan lebih baik dari Naive.** Dari 36 run, nol run memenuhi kriteria terkunci (`MAE_vs_naive_pct < 0` **dan** `DM_MAE < 0` **dan** `p_MAE < 0,05`). Tujuh run punya MAE lebih kecil dari Naive, tetapi p-value terkecil di antara mereka hanya 0,124 — jauh dari 0,05, jadi keunggulannya tidak bisa dibedakan dari kebetulan.

Sel yang signifikan secara statistik hanya ada di horizon pendek — `candle_1m` h1 dan `ticker_5m` h5 (semua model, p < 0,01) plus `candle_1m` h5 CatBoost (p = 0,038) — tetapi arahnya semua **positif**, artinya model lebih buruk dari Naive. Jadi yang terbukti secara statistik justru kebalikannya: di horizon sangat pendek, Naive menang meyakinkan.

Pola yang konsisten: makin panjang horizon, makin baik posisi model terhadap Naive. Horizon 60 menit adalah satu-satunya horizon di mana keempat model pada kedua dataset semuanya mengalahkan Naive, meski tidak signifikan.

## 4. Skor pasangan (dataset, horizon) dan pilihan untuk Tahap 2

Skor = `MAE_vs_naive_pct` terkecil di antara keempat model pada pasangan itu.

| dataset | horizon_menit | skor_data_baru | skor_tahap1_lama |
|---|---|---|---|
| ticker_5m | 60 | -0.330 | 0.016 |
| candle_1m | 60 | -0.231 | -0.159 |
| ticker_5m | 30 | -0.003 | 0.034 |
| candle_1m | 30 | 0.012 | 0.010 |
| candle_1m | 15 | 0.028 | 0.084 |
| ticker_5m | 15 | 0.090 | 0.132 |
| candle_1m | 1 | 0.095 | -0.347 |
| candle_1m | 5 | 0.122 | 0.060 |
| ticker_5m | 5 | 0.238 | 0.160 |

Sesuai **aturan 2** di `KEPUTUSAN_TERKUNCI.md` (tidak ada yang signifikan → pilih skor terkecil, dan tulis jelas bahwa tidak ada yang signifikan):

**Pasangan terpilih: `ticker_5m`, horizon 60 menit** — skor −0,330 (CatBoost, p_MAE = 0,137, akurasi arah 57,8%). Latih 7.275 bar, uji 1.822 bar.

## 5. Perbandingan dengan Tahap 1 asli (data 1 minggu)

| | Tahap 1 asli | Tahap 1 data baru |
|---|---|---|
| Periode | 14–20 Okt 2026 (7 hari) | 10 Okt–10 Nov 2026 (31,7 hari) |
| Bar candle 1m terpakai | 10.078 | 45.661 |
| Pasangan terpilih | `candle_1m` h1 | `ticker_5m` h60 |
| Skor terbaik | −0,347 (CatBoost, p=0,395) | −0,330 (CatBoost, p=0,137) |
| Run signifikan lebih baik dari Naive | 0 dari 36 | 0 dari 36 |

Kesimpulan besarnya **tidak berubah**: dengan data 4,5× lebih panjang pun tidak ada model yang signifikan mengalahkan Naive. Yang berubah adalah pasangan terpilih — dari horizon 1 menit ke 60 menit. Ini perlu dicatat jujur di skripsi: pilihan time frame Tahap 1 **tidak stabil antar periode**, karena yang diperingkat adalah selisih yang semuanya tidak signifikan, jadi urutannya mudah bertukar oleh noise.

Satu hal yang menguatkan data baru: ranking horizon di data 31 hari jauh lebih rapi — membaik monoton dari h5 ke h60 di kedua dataset — sedangkan di data 1 minggu h1 melonjak sendiri ke peringkat atas tanpa pola pendukung. Pola monoton lebih mudah dipertanggungjawabkan secara teori.

## 6. Catatan teknis

- Proses sempat terhenti (killed) di run ke-34; 33 run sudah tersimpan, 3 run sisa (`ticker_5m` h60 LightGBM/CatBoost/AdaBoost) dilanjutkan terpisah. Logika lewati-run `run.py` memastikan tidak ada run ganda maupun yang terlewat — kelengkapan 36 run sudah diverifikasi.
- AdaBoost sangat lambat di `candle_1m` (±17 menit/run, vs LightGBM 9–20 detik) karena fit sekuensial pada 45 ribu baris. Kalau Tahap 2–4 diulang di data baru, AdaBoost jadi penentu total waktu.
- AdaBoost juga paling buruk di hampir semua sel, puncaknya +2,58% di `ticker_5m` h30.
- Tabel di laporan ini ditulis manual karena paket `tabulate` belum terpasang di venv. Tidak ada paket baru dipasang.

## 7. Keputusan yang menunggu Ferdi

Sesuai aturan terkunci, proses **berhenti di sini**. Yang perlu ditetapkan:

1. Apakah data 31 hari ini yang dipakai untuk skripsi, atau tetap data 1 minggu? Di `KEPUTUSAN_TERKUNCI.md` status ini masih tertulis *belum dipastikan ke dosen*.
2. Kalau pakai data baru: Tahap 2–4 perlu diulang penuh pada pasangan `ticker_5m` h60, dan `KEPUTUSAN_TERKUNCI.md` perlu diganti dokumen kunci baru yang bertanggal — bukan diedit di tempat.
3. Kalau dua periode dilaporkan berdampingan sebagai uji ketahanan, itu justru bahan kuat untuk Bab 4: kesimpulan utama konsisten, dan ketidakstabilan pilihan time frame bisa dibahas terbuka.
