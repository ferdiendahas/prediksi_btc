# REKAP PERCOBAAN 2 (P2) — SELURUH TAHAP 1–4

**Eksperimen data 31 hari (10 Okt – 10 Nov 2026), BTC/IDR Indodax.**  
Dibuat 2026-11-11. Bagian 1–7 faktual. Bagian 8 memisahkan mana yang sudah ditetapkan aturan dan mana yang masih perlu keputusan Ferdi.

Sumber: `hasil/hasil_semua.csv` (baris bertag `p2_*`: 120 run model + 17 baris Naive) dan `LAPORAN_P2_TAHAP1.md` … `LAPORAN_P2_TAHAP4.md`.

> **Hubungan dengan Percobaan 1.** P1 memakai data satu minggu (14–20 Okt 2026) dan direkap di `REKAP_SEMUA_TAHAP.md`. P2 mengulang keempat tahap pada data 4,5× lebih panjang. Keduanya berdiri sendiri; tidak ada baris P1 yang diubah atau dihapus.

---

## 1. Apa yang dijalankan

| Tahap | Tujuan | Variasi | Run | Durasi |
|---|---|---|---|---|
| 1 | cari time frame | 2 dataset × 5 horizon × 4 model, `tpe`, 80:20 | 36 | ±66 m |
| 2 | bandingkan metode optimasi | 7 metode × 4 model, `ticker_5m` h60, 80:20 | 28 | 11 m 18 s |
| 3 | uji rasio split | 3 split × 2 metode × 4 model, `ticker_5m` h60 | 24 | 8 m 22 s |
| 4 | teknik tambahan | 4 teknik × 2 metode × 4 model, `ticker_5m` h60, 80:20 | 32 | 10 m 8 s |
| **Total** | | | **120** | **±96 m** |

Gagal: **0 dari 120**, semua exit code 0. Tahap 1 sempat terhenti (killed) di run ke-34; 33 run sudah tersimpan dan 3 run sisa dilanjutkan terpisah — logika lewati-run `run.py` memastikan tidak ada run ganda maupun yang terlewat, dan kelengkapan 36 run diverifikasi ulang.

Keputusan yang diambil di jalan:

- Tahap 1 → pasangan **`ticker_5m`, horizon 60 menit** (Aturan 2: tidak ada yang signifikan, ambil skor terkecil)
- Tahap 2 → metode **`cmaes`** (rata-rata 4 model terkecil, tanpa seri)
- Tahap 3 dan 4 → tidak ada pemilihan; keduanya dijalankan dengan `cmaes` **dan** `tpe` atas permintaan Ferdi (penyimpangan dari aturan terkunci, tercatat di `LOG_PERUBAHAN.md`)

## 2. Hasil per tahap

| tag | run | rata_MAE_vs_naive | terbaik | rata_RMSE_vs_naive | rata_akurasi_arah | DATAR |
|---|---|---|---|---|---|---|
| p2_tahap1 | 36 | 0.220 | -0.330 | 0.074 | 52.948 | 21/36 |
| p2_tahap2 | 28 | 1.909 | -0.749 | 1.385 | 55.517 | 6/28 |
| p2_tahap3 | 24 | 0.335 | -0.749 | 0.295 | 55.053 | 8/24 |
| p2_tahap4_earlystop | 8 | -0.182 | -0.749 | 0.490 | 56.133 | 0/8 |
| p2_tahap4_lossl1 | 8 | -0.029 | -0.749 | 0.156 | 55.531 | 5/8 |
| p2_tahap4_prunermedian | 8 | 0.117 | -0.330 | 0.155 | 56.056 | 3/8 |
| p2_tahap4_topk15 | 8 | 0.029 | -0.418 | 0.498 | 56.526 | 1/8 |

Rata-rata `p2_tahap1` dan `p2_tahap2` terangkat oleh run buruk: Tahap 1 mencakup semua horizon termasuk yang jauh lebih buruk dari Naive, Tahap 2 mencakup `default` yang rata-ratanya +11,57.

## 3. Tahap 1 — time frame

| dataset | horizon_menit | XGBoost | LightGBM | CatBoost | AdaBoost | skor |
|---|---|---|---|---|---|---|
| candle_1m | 1 | 0.837 | 0.095 | 0.632 | 0.621 | 0.095 |
| candle_1m | 5 | 0.181 | 0.122 | 0.311 | 0.640 | 0.122 |
| candle_1m | 15 | 0.067 | 0.078 | 0.028 | 0.030 | 0.028 |
| candle_1m | 30 | 0.042 | 0.042 | 0.040 | 0.012 | 0.012 |
| candle_1m | 60 | -0.231 | -0.137 | -0.181 | -0.166 | -0.231 |
| ticker_5m | 5 | 0.241 | 0.240 | 0.238 | 0.551 | 0.238 |
| ticker_5m | 15 | 0.133 | 0.099 | 0.090 | 0.272 | 0.090 |
| ticker_5m | 30 | 0.031 | 0.053 | -0.003 | 2.578 | -0.003 |
| ticker_5m | 60 | -0.284 | -0.221 | -0.330 | 1.186 | -0.330 |

Pola monoton: makin panjang horizon, makin baik posisi model. Horizon 60 menit satu-satunya di mana keempat model pada kedua dataset mengalahkan Naive. **Pasangan terpilih: `ticker_5m` h60** (skor −0,330; CatBoost, p_MAE 0,137).

## 4. Tahap 2 — metode optimasi (`ticker_5m` h60, 80:20)

| optimasi | XGBoost | LightGBM | CatBoost | AdaBoost | rata2 | rata2_tanpa_Ada |
|---|---|---|---|---|---|---|
| cmaes | -0.251 | -0.140 | -0.284 | -0.749 | -0.356 | -0.225 |
| tpe | -0.284 | -0.221 | -0.330 | 1.186 | 0.088 | -0.279 |
| qmc | -0.235 | -0.325 | -0.259 | 1.215 | 0.099 | -0.273 |
| ga | -0.289 | -0.140 | -0.260 | 1.754 | 0.266 | -0.230 |
| grid | -0.117 | -0.251 | -0.199 | 2.994 | 0.607 | -0.189 |
| random | -0.150 | -0.278 | -0.290 | 5.079 | 1.090 | -0.239 |
| default | 16.915 | 10.804 | 10.235 | 8.310 | 11.566 | 12.651 |

**Metode terpilih: `cmaes`** (rata-rata −0,356, satu-satunya negatif). Tetapi kemenangannya praktis seluruhnya dari AdaBoost: tanpa AdaBoost, `tpe` (−0,279) justru unggul atas `cmaes` (−0,225), dan keenam metode berkerumun di −0,19 s.d. −0,28. Untuk tiga model utama, std antar metode hanya 0,04–0,07 poin persen — tidak terbedakan.

## 5. Tahap 3 — rasio split (`ticker_5m` h60, `cmaes` + `tpe`)

| split | optimasi | XGBoost | LightGBM | CatBoost | AdaBoost |
|---|---|---|---|---|---|
| 60:40 | cmaes | -0.006 | -0.006 | 0.011 | 5.863 |
| 60:40 | tpe | -0.006 | -0.008 | -0.001 | 2.476 |
| 70:30 | cmaes | -0.068 | -0.161 | -0.167 | 2.072 |
| 70:30 | tpe | 0.008 | -0.070 | -0.201 | -0.628 |
| 80:20 | cmaes | -0.251 | -0.140 | -0.284 | -0.749 |
| 80:20 | tpe | -0.284 | -0.221 | -0.330 | 1.186 |

Rata-rata tiga model utama: 80:20 ≈ −0,25 → 70:30 ≈ −0,11 → 60:40 ≈ −0,00. Keunggulan atas Naive menyusut rapi seiring data latih mengecil, konsisten di kedua metode; akurasi arah ikut turun 55–58% → 53–54%. **Tidak ada pemilihan**, 80:20 tetap dipakai Tahap 4.

## 6. Tahap 4 — teknik tambahan (selisih terhadap baseline Tahap 2)

**Early stopping** (0/8 DATAR) — negatif = membantu:

| model | cmaes | tpe | selisih_cmaes | selisih_tpe |
|---|---|---|---|---|
| XGBoost | -0.528 | -0.461 | -0.278 | -0.177 |
| LightGBM | -0.490 | -0.268 | -0.349 | -0.047 |
| CatBoost | 0.105 | -0.249 | 0.389 | 0.081 |
| AdaBoost | -0.749 | 1.186 | 0.000 | 0.000 |

**Top-k 15 fitur** (1/8 DATAR) — negatif = membantu:

| model | cmaes | tpe | selisih_cmaes | selisih_tpe |
|---|---|---|---|---|
| XGBoost | -0.151 | -0.210 | 0.100 | 0.074 |
| LightGBM | -0.302 | -0.282 | -0.161 | -0.061 |
| CatBoost | -0.333 | -0.271 | -0.050 | 0.059 |
| AdaBoost | -0.418 | 2.203 | 0.331 | 1.016 |

**Loss L1** (5/8 DATAR) — negatif = membantu:

| model | cmaes | tpe | selisih_cmaes | selisih_tpe |
|---|---|---|---|---|
| XGBoost | -0.117 | -0.117 | 0.134 | 0.167 |
| LightGBM | -0.111 | -0.132 | 0.030 | 0.089 |
| CatBoost | -0.087 | -0.105 | 0.197 | 0.226 |
| AdaBoost | -0.749 | 1.186 | 0.000 | 0.000 |

**Pruner median** (3/8 DATAR) — negatif = membantu:

| model | cmaes | tpe | selisih_cmaes | selisih_tpe |
|---|---|---|---|---|
| XGBoost | -0.140 | -0.284 | 0.110 | 0.000 |
| LightGBM | -0.140 | -0.221 | 0.000 | 0.000 |
| CatBoost | -0.291 | -0.330 | -0.008 | 0.000 |
| AdaBoost | 1.157 | 1.186 | 1.906 | 0.000 |

## 7. Temuan pokok seluruh P2

### 7a. Satu dari 120 run signifikan lebih baik dari Naive — dan itu LEBIH SEDIKIT dari harapan kebetulan

> **`ticker_5m`, h60, 80:20, LightGBM, `cmaes`, `--loss l1`**  
> MAE Rp3.541.748 vs Naive Rp3.545.674 (**−0,111%**), `DM_MAE` −2,104, `p_MAE` **0,0355**, akurasi arah 56,86%.

Ini satu-satunya run dari 120 yang memenuhi kriteria terkunci. **Tetapi di bawah 120 pengujian pada data yang sama, α = 0,05 memperkirakan sekitar 3 run lolos ke arah "lebih baik" (dua-sisi) murni karena kebetulan.** Dapat 1 berarti hasilnya *di bawah* yang diharapkan kebetulan. Dengan koreksi Bonferroni (α/120 = 0,000417) run ini jelas tidak signifikan. Jadi temuan ini **tidak boleh** dijadikan hasil utama skripsi.

Tiga faktor lain yang mengecilkan bobotnya:

- `RMSE_vs_naive_pct` = −0,002% dengan `p_RMSE` = 0,96 → nol keunggulan pada error kuadrat
- `rasio_sebaran` = 5,8e−03 → prediksi bergerak hanya 0,58% sebesar harga sebenarnya; **status DATAR**
- Penghematan Rp3.926 per prediksi vs spread bid-ask rata-rata Rp599.762 → **153× lebih kecil dari spread**, mustahil dimanfaatkan

Penjelasan mekanisnya: L1 adalah loss yang persis mengoptimalkan MAE (metrik utama penelitian). Menyamakan loss latih dengan metrik evaluasi membuat prediksi tertarik ke median kondisional return, dan menebak median yang nyaris-nol mengalahkan menebak nol persis pada loss absolut — tanpa perlu kemampuan memprediksi arah per waktu. Tiga run L1 lain nyaris lolos (p = 0,061; 0,061; 0,100), jadi ini pola yang bisa dijelaskan, bukan keberuntungan satu run.

### 7b. Yang signifikan justru arah sebaliknya

| | jumlah |
|---|---|
| run dengan `p_MAE` < 0,05 (dua arah) | 16 dari 120 |
| di antaranya: signifikan lebih **baik** | **1** |
| di antaranya: signifikan lebih **buruk** | **15** |

Ke-15 run yang signifikan lebih buruk: 9 di Tahap 1 (horizon pendek `candle_1m` h1 dan `ticker_5m` h5), 4 baris `default` di Tahap 2, 1 AdaBoost `random`, 1 AdaBoost 60:40 `cmaes`. Jadi uji DM memang punya daya untuk mendeteksi perbedaan di data ini — dan yang terdeteksi hampir seluruhnya adalah model yang kalah dari Naive, bukan menang.

### 7c. 44 dari 120 run (37%) tidak benar-benar memprediksi

Diagnostik `sebaran_prediksi` yang ditambahkan ke `ringkas.py` pada 2026-11-11 mengungkap bahwa 37% run menghasilkan prediksi datar (`n_unik` ≤ 3 atau `rasio_sebaran` < 0,01). Kasus paling ekstrem: XGBoost `ticker_5m` h60 60:40 mengeluarkan **satu nilai identik untuk seluruh 3.644 baris uji**, dan tercatat −0,006% terhadap Naive — angka yang tanpa diagnostik ini terbaca sebagai "menang tipis".

Bahkan run yang berstatus `ok` nyaris datar: median `rasio_sebaran` seluruh P2 hanya **0,017**, artinya prediksi model tipikal bergerak **1,7%** sebesar pergerakan harga sebenarnya. Nilai tertinggi 0,453 (AdaBoost, yang justru paling tidak akurat).

Dampak pada Tahap 1: **lima dari tujuh run yang "mengalahkan Naive" ternyata datar**, semuanya di `candle_1m` h60 (keempat model DATAR; LightGBM hanya 3 nilai unik). Pasangan yang terpilih, `ticker_5m` h60, justru paling sehat — 1 dari 4 model DATAR dan pemenangnya berstatus `ok`. Aturan terkunci kebetulan mengarahkan ke pasangan yang benar.

### 7d. Keunggulan kecil di 80:20 sebagian berasal dari tren, bukan prediksi

Harga BTC turun di semua periode uji (−6% s.d. −11%). Semua model memprediksi return rata-rata negatif (−6e−05 s.d. −9e−05) searah tren, sementara Naive selalu nol. Di pasar yang turun terus, menambahkan pergeseran negatif konstan sudah cukup untuk mengalahkan Naive sedikit. Pengecualian: run signifikan di 7a punya `geser_rata2` ≈ 0, jadi keunggulan run itu bukan dari tren.

### 7e. MAE dan RMSE berlawanan arah di horizon pendek

Dua run di Tahap 1 signifikan lebih baik pada **RMSE** sekaligus signifikan lebih buruk pada **MAE** — keduanya `candle_1m` h1, 80:20:

| model | RMSE vs Naive | p_RMSE | MAE vs Naive | p_MAE |
|---|---|---|---|---|
| XGBoost | −1,154% | 0,000 | +0,837% | 0,001 |
| CatBoost | −0,602% | 0,008 | +0,632% | 0,001 |

Artinya model menekan error besar tetapi memperburuk error tipikal. Dokumen terkunci menetapkan MAE sebagai metrik utama sebelum hasil dilihat dan **itu tidak diganti** — justru itu gunanya dikunci. Tapi divergensi ini hasil substantif yang layak dibahas di Bab 4, bukan disembunyikan. Catatan: arah divergensi ini berbeda dari P1, yang polanya model menang di RMSE secara luas.

### 7f. Yang menentukan hasil bukan model atau metode optimasi

| bukti | dari |
|---|---|
| `default` +8% s.d. +17% vs semua metode tuning −0,1% s.d. −0,3% | Tahap 2 |
| antar enam metode tuning: std 0,04–0,07 poin persen untuk 3 model utama | Tahap 2 |
| menyusut rapi saat data latih dikurangi, sampai model berhenti memprediksi di 19 hari | Tahap 3 |
| 37% run berakhir datar; median `rasio_sebaran` 0,017 | seluruh P2 |

Kesimpulan: faktor pembatas adalah **rasio sinyal terhadap noise pada return 60 menit**, bukan pilihan model, metode optimasi, rasio split, atau teknik tambahan. Ada-tidaknya tuning penting; sisanya nyaris tidak.

## 8. Keputusan

### 8a. Yang sudah ditetapkan aturan terkunci

| | pilihan | dasar |
|---|---|---|
| Time frame | `ticker_5m`, horizon **60 menit** | Tahap 1, Aturan 2: skor terkecil (−0,330); tidak ada yang signifikan |
| Metode optimasi | **`cmaes`** | Tahap 2: rata-rata 4 model terkecil (−0,356); `default` terlarang; tidak seri |
| Rasio split | tidak dipilih — ketiganya dilaporkan | Tahap 3 tidak punya aturan pemilihan |
| Teknik tambahan | tidak dipilih — selisih dilaporkan | Tahap 4 tidak punya aturan pemilihan |

### 8b. Empat hal yang masih keputusan Ferdi

**1. Data mana yang dipakai untuk skripsi.** `KEPUTUSAN_TERKUNCI.md` masih mencatat status data *belum dipastikan ke dosen*, dan mengunci periode Tahap 1 pada 14–20 Okt 2026. Selama itu belum diputuskan, P1 dan P2 sama-sama berstatus eksperimen, bukan hasil final. Pilihan: (a) P2 jadi hasil utama dan dokumen kunci baru dibuat bertanggal, (b) P1 tetap utama dan P2 jadi uji ketahanan, atau (c) keduanya dilaporkan berdampingan.

Rekomendasi saya: **(c)**. Dua periode dengan kesimpulan utama identik (0 dan 1 run signifikan dari 92 dan 120) adalah bukti ketahanan yang jauh lebih kuat daripada satu periode saja — dan ketidakstabilan pilihan time frame antar periode (`candle_1m` h1 vs `ticker_5m` h60) justru bahan diskusi yang bagus: ia menunjukkan bahwa memperingkat selisih yang tidak signifikan memang tidak stabil.

**2. Apakah metode optimasi untuk Tahap 3–4 tetap `cmaes`.** Dasarnya tipis (satu angka AdaBoost yang tidak signifikan, dan tidak bertahan saat rasio digeser). Karena itu Tahap 3 dan 4 sudah dijalankan dengan `cmaes` **dan** `tpe` — jadi kamu punya data untuk memilih mana yang dilaporkan, atau melaporkan keduanya.

**3. Bagaimana run signifikan di 7a ditulis.** Sudah lengkap dengan konteks pembatalnya (Bonferroni, p_RMSE 0,96, status DATAR, 153× spread). Yang perlu diputuskan: apakah ini ditulis sebagai temuan yang dibahas kritis, atau sebagai catatan kaki. Sebaiknya dikonfirmasi ke dosen — ini satu-satunya angka di seluruh penelitian yang bisa disalahbaca sebagai keberhasilan.

**4. Apakah perlu Percobaan 3 dengan arah berbeda.** Bila yang diinginkan hasil positif, bukti di 7f menunjukkan menambah model atau metode optimasi tidak akan menolong. Yang punya peluang: horizon lebih panjang (harian), atau mengubah masalah dari regresi harga menjadi klasifikasi arah dengan ambang di luar spread (> 0,0433%).

### 8c. Catatan untuk Bab 3 dan 4

| temuan | implikasi yang perlu ditulis |
|---|---|
| LightGBM `cmaes` dan `ga` identik di Tahap 2 | seed dan trial acak awal sama (README bagian 6 nomor 5); keduanya jatuh ke solusi datar yang sama |
| `grid` memakai 27 trial, lainnya 30 | jumlah evaluasi antar metode tidak setara |
| AdaBoost tidak terpengaruh `--loss` dan `--early-stop` | README bagian 6 nomor 7; selisihnya tepat 0,000 — sekaligus uji kewarasan pipeline |
| `--pruner median` memangkas 6–22 trial, hasil `tpe` identik 0,000 | pruner bekerja benar: yang dipangkas memang trial jelek |
| AdaBoost ±17 menit/run di `candle_1m` vs LightGBM 9–20 detik | fit sekuensial pada 45 ribu baris; penentu total waktu Tahap 1 |
| AdaBoost tidak stabil: −0,749 → +1,186 → +2,072 → −0,628 → +5,863 | tidak layak dijadikan dasar kesimpulan apa pun |
| 37% run berprediksi datar | perlu dilaporkan, bukan dibuang: model memilih setelan yang meredam dirinya sampai memprediksi satu nilai |

## 9. Peta berkas P2

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | 137 baris bertag `p2_*` (120 run model + 17 Naive), 39 kolom |
| `hasil/laporan/LAPORAN_P2_TAHAP1.md` … `TAHAP4.md` | laporan faktual per tahap |
| `hasil/laporan/REKAP_P2_SEMUA_TAHAP.md` | berkas ini |
| `hasil/laporan/p2_*_ringkasan.txt` | keluaran `ringkas.py` per tag (7 berkas) |
| `hasil/laporan/p2_*_stdout.txt` | keluaran mentah `run.py` (7 berkas) |
| `hasil/laporan/p2_tahap*_waktu.txt` | waktu mulai/selesai (4 berkas) |
| `hasil/ringkasan/p2_*/` | arsip CSV ringkasan per tahap, termasuk `sebaran_prediksi.csv` (7 folder) |
| `hasil/params/*p2_*.json` | 120 JSON: hyperparameter terbaik + daftar fitur |
| `hasil/prediksi/*p2_*.csv` | 120 CSV: prediksi data uji per run |
| `hasil/metadata/p2_data.txt` | SHA-256, jumlah baris, rentang waktu, keutuhan data P2 |
| `hasil/metadata/p2_config_dipakai.py` | salinan `config.py` saat P2 dijalankan |
| `hasil/metadata/p2_perangkat.txt` | perangkat dan versi paket (sama dengan P1) |
| `hasil/LOG_PERUBAHAN.md` | semua perubahan kode, termasuk `sebaran_prediksi` dan penyimpangan dua-metode |
| `hasil/KEPUTUSAN_TERKUNCI.md` | desain P1, dikunci 27 Okt 2026 — **tidak diubah untuk P2** |
