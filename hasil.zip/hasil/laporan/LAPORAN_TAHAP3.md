# LAPORAN TAHAP 3 — Uji Rasio Pembagian Data

**Eksperimen data satu minggu (14–20 Okt 2026).**
Dibuat 2026-10-28. Laporan faktual; tidak memuat interpretasi atau kesimpulan.

Pasangan dan metode diambil dari tahap sebelumnya: **`candle_1m`, horizon 1 menit**
(Tahap 1) dan **metode optimasi `tpe`** (Tahap 2).

**Tahap ini tidak memiliki aturan pemilihan.** Ketiga rasio dilaporkan apa adanya.

---

## 1. Perintah persis yang dijalankan

```bash
source .venv/bin/activate
caffeinate -i python run.py --datasets candle_1m --horizons 1 --optimizers tpe \
  --splits 0.8 0.7 0.6 --tag tahap3
python ringkas.py --tag tahap3 > hasil/laporan/tahap3_ringkasan.txt
```

Keluaran mentah di `hasil/laporan/tahap3_stdout.txt`. Pengaturan lain dari
`config.py`: `N_TRIALS` 30, `N_FOLDS` 5, `PRUNER` None, `EARLY_STOP` False,
`TOP_K` None, `LOSS` l2, `SEED` 42, periode 2026-10-14 00:00 s.d.
2026-10-20 23:59 UTC.

---

## 2. Waktu

| | |
|---|---|
| Mulai | 2026-10-28 07:28:24 WIB |
| Selesai | 2026-10-28 07:39:00 WIB |
| Durasi total (wall clock) | 10 menit 36 detik (10,6 menit) |
| Jumlah `detik_total` semua run | 634,8 detik |
| Jumlah `detik_tuning` semua run | 621,6 detik |
| Exit code | 0 |

---

## 3. Jumlah run

| | |
|---|---|
| Direncanakan (brief) | 12 (4 model × 3 split) |
| Maksimum menurut `run.py` | 12 |
| Dilewati karena kombinasi tidak valid | 0 |
| Selesai | **12** |
| Gagal | **0** |

Tidak ada pesan error. Baris Naive yang dicatat: 3 (satu per rasio split).
Total baris bertag `tahap3`: 15. Total baris `hasil/hasil_semua.csv`: 89.

`n_trials` = 30 dan `n_pruned` = 0 pada semua run. Jumlah fitur: 42.

---

## 4. Tabel lengkap semua run Tahap 3

Persen dibulatkan 3 desimal, rupiah bilangan bulat, p-value 4 desimal.
`MAE_vs_naive_pct` negatif = MAE lebih kecil daripada Naive **pada periode uji
rasio itu sendiri**.

| dataset | horizon_menit | split | model | optimasi | MAE_Rp | RMSE_Rp | MAPE_pct | Akurasi_arah_pct | MAE_vs_naive_pct | RMSE_vs_naive_pct | DM_MAE | p_MAE | DM_RMSE | p_RMSE | n_latih | n_uji | n_trials | detik_total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | AdaBoost | tpe | 349,047 | 623,438 | 0.024 | 54.426 | -0.066 | -2.058 | -0.13 | 0.8966 | -5.377 | 0.0 | 8,062 | 2,016 | 30 | 92.2 |
| candle_1m | 1 | 80:20 | CatBoost | tpe | 348,066 | 622,845 | 0.024 | 56.818 | -0.347 | -2.151 | -0.85 | 0.3952 | -6.193 | 0.0 | 8,062 | 2,016 | 30 | 79.2 |
| candle_1m | 1 | 80:20 | LightGBM | tpe | 348,157 | 625,799 | 0.024 | 56.699 | -0.321 | -1.687 | -1.044 | 0.2964 | -6.32 | 0.0 | 8,062 | 2,016 | 30 | 4.7 |
| candle_1m | 1 | 80:20 | XGBoost | tpe | 348,262 | 618,940 | 0.024 | 57.476 | -0.291 | -2.765 | -0.546 | 0.5848 | -6.128 | 0.0 | 8,062 | 2,016 | 30 | 67.0 |
| candle_1m | 1 | 70:30 | AdaBoost | tpe | 318,591 | 575,770 | 0.022 | 54.163 | 0.241 | -2.23 | 0.356 | 0.7218 | -3.582 | 0.0003 | 7,054 | 3,024 | 30 | 122.2 |
| candle_1m | 1 | 70:30 | CatBoost | tpe | 318,485 | 575,104 | 0.022 | 54.399 | 0.207 | -2.343 | 0.473 | 0.6366 | -6.174 | 0.0 | 7,054 | 3,024 | 30 | 19.3 |
| candle_1m | 1 | 70:30 | LightGBM | tpe | 318,417 | 584,890 | 0.022 | 53.771 | 0.186 | -0.681 | 1.534 | 0.1251 | -7.516 | 0.0 | 7,054 | 3,024 | 30 | 3.9 |
| candle_1m | 1 | 70:30 | XGBoost | tpe | 318,478 | 573,215 | 0.022 | 56.167 | 0.205 | -2.664 | 0.435 | 0.6633 | -6.749 | 0.0 | 7,054 | 3,024 | 30 | 60.7 |
| candle_1m | 1 | 60:40 | AdaBoost | tpe | 304,665 | 561,831 | 0.021 | 51.946 | 0.165 | -0.085 | 6.928 | 0.0 | -4.956 | 0.0 | 6,046 | 4,032 | 30 | 77.9 |
| candle_1m | 1 | 60:40 | CatBoost | tpe | 303,699 | 553,402 | 0.021 | 56.25 | -0.153 | -1.584 | -0.811 | 0.4174 | -9.732 | 0.0 | 6,046 | 4,032 | 30 | 46.3 |
| candle_1m | 1 | 60:40 | LightGBM | tpe | 304,553 | 558,439 | 0.021 | 55.041 | 0.128 | -0.688 | 1.406 | 0.1599 | -10.003 | 0.0 | 6,046 | 4,032 | 30 | 4.1 |
| candle_1m | 1 | 60:40 | XGBoost | tpe | 303,630 | 546,134 | 0.021 | 56.899 | -0.175 | -2.877 | -0.458 | 0.6466 | -8.849 | 0.0 | 6,046 | 4,032 | 30 | 57.3 |

---

## 5. Baris Naive per rasio split

| dataset | horizon_menit | split | MAE_Rp | RMSE_Rp | MAPE_pct | n_latih | n_uji | latih_mulai | uji_mulai | uji_akhir |
|---|---|---|---|---|---|---|---|---|---|---|
| candle_1m | 1 | 80:20 | 349,278 | 636,540 | 0.024 | 8,062 | 2,016 | 2026-10-14 00:00:00 | 2026-10-19 14:23:00 | 2026-10-20 23:58:00 |
| candle_1m | 1 | 70:30 | 317,826 | 588,901 | 0.022 | 7,054 | 3,024 | 2026-10-14 00:00:00 | 2026-10-18 21:35:00 | 2026-10-20 23:58:00 |
| candle_1m | 1 | 60:40 | 304,163 | 562,309 | 0.021 | 6,046 | 4,032 | 2026-10-14 00:00:00 | 2026-10-18 04:47:00 | 2026-10-20 23:58:00 |

**MAE dan RMSE rupiah antar-rasio tidak dapat dibandingkan langsung** karena
periode ujinya berbeda: 60:40 menguji 4.032 bar mulai 2026-10-18 04:47, 70:30
menguji 3.024 bar mulai 2026-10-18 21:35, 80:20 menguji 2.016 bar mulai
2026-10-19 14:23. Ketiganya berakhir di 2026-10-20 23:58. Nilai Naive menurun
dari Rp349.278 (80:20) ke Rp304.163 (60:40) karena periode uji yang lebih panjang
memasukkan jam-jam dengan pergerakan harga lebih kecil, bukan karena modelnya
berbeda. Perbandingan yang sahih hanya `MAE_vs_naive_pct` **di dalam** rasio yang
sama.

---

## 6. Hasil ketiga rasio (tanpa pemilihan)

### 6a. `MAE_vs_naive_pct` per rasio dan model

| split | n_latih | n_uji | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata 4 model |
|---|---|---|---|---|---|---|---|
| 80:20 | 8.062 | 2.016 | -0.291 | -0.321 | -0.347 | -0.066 | **-0.2563** |
| 70:30 | 7.054 | 3.024 | 0.205 | 0.186 | 0.207 | 0.241 | **0.2097** |
| 60:40 | 6.046 | 4.032 | -0.175 | 0.128 | -0.153 | 0.165 | **-0.0087** |

Jumlah run dengan `MAE_vs_naive_pct < 0` per rasio: 80:20 → 4 dari 4;
70:30 → 0 dari 4; 60:40 → 2 dari 4 (XGBoost dan CatBoost).

### 6b. `RMSE_vs_naive_pct` per rasio dan model

| split | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata 4 model |
|---|---|---|---|---|---|
| 80:20 | -2.765 | -1.687 | -2.151 | -2.058 | **-2.1655** |
| 70:30 | -2.664 | -0.681 | -2.343 | -2.230 | **-1.9793** |
| 60:40 | -2.877 | -0.688 | -1.584 | -0.085 | **-1.3085** |

Seluruh 12 run memiliki `RMSE_vs_naive_pct < 0`.

### 6c. Akurasi arah (%) per rasio dan model

| split | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata 4 model |
|---|---|---|---|---|---|
| 80:20 | 57.476 | 56.699 | 56.818 | 54.426 | **56.355** |
| 70:30 | 56.167 | 53.771 | 54.399 | 54.163 | **54.625** |
| 60:40 | 56.899 | 55.041 | 56.250 | 51.946 | **55.034** |

### 6d. Waktu

| split | total `detik_total` 4 model |
|---|---|
| 80:20 | 243,2 s |
| 70:30 | 206,1 s |
| 60:40 | 185,5 s |

### 6e. Status signifikansi

Memakai definisi terkunci (`MAE_vs_naive_pct < 0` **dan** `DM_MAE < 0` **dan**
`p_MAE < 0.05`): **0 dari 12 run Tahap 3 signifikan lebih baik dari Naive.**
`p_MAE` terkecil di antara run yang `MAE_vs_naive_pct < 0` adalah 0,3952
(CatBoost 80:20). Lihat catatan teknis nomor 3 untuk satu run yang signifikan
dengan arah sebaliknya.

---

## 7. Hyperparameter terbaik per rasio

Konfigurasi: `candle_1m`, harga `typical`, horizon 1 menit, optimasi `tpe`,
`loss` l2, tanpa early stopping, tanpa seleksi fitur, tanpa pruner, 30 trial,
5 fold, 42 fitur. Sumber: `hasil/params/`.

### Split 80:20

| model | hyperparameter terbaik |
|---|---|
| XGBoost | `n_estimators` 452, `max_depth` 7, `learning_rate` 0.0031346, `min_child_weight` 48, `subsample` 0.74621, `colsample_bytree` 0.55215, `reg_lambda` 0.30546, `reg_alpha` 0.0053916 |
| LightGBM | `n_estimators` 27, `num_leaves` 25, `max_depth` 7, `learning_rate` 0.014728, `min_child_samples` 28, `subsample` 0.59400, `colsample_bytree` 0.92573, `reg_lambda` 4.22932, `reg_alpha` 0.0034210, `subsample_freq` 1 |
| CatBoost | `iterations` 420, `depth` 8, `learning_rate` 0.0016139, `l2_leaf_reg` 0.10368, `random_strength` 1.18432, `bagging_temperature` 0.56779 |
| AdaBoost | `n_estimators` 32, `learning_rate` 0.0019634, `loss` linear, `max_depth` 3 |

### Split 70:30

| model | hyperparameter terbaik |
|---|---|
| XGBoost | `n_estimators` 452, `max_depth` 7, `learning_rate` 0.0031346, `min_child_weight` 48, `subsample` 0.74621, `colsample_bytree` 0.55215, `reg_lambda` 0.30546, `reg_alpha` 0.0053916 |
| LightGBM | `n_estimators` 23, `num_leaves` 6, `max_depth` 8, `learning_rate` 0.0085306, `min_child_samples` 41, `subsample` 0.74327, `colsample_bytree` 0.97494, `reg_lambda` 0.15229, `reg_alpha` 0.010165, `subsample_freq` 1 |
| CatBoost | `iterations` 134, `depth` 5, `learning_rate` 0.0059447, `l2_leaf_reg` 9.91490, `random_strength` 0.082306, `bagging_temperature` 0.40587 |
| AdaBoost | `n_estimators` 88, `learning_rate` 0.0012701, `loss` square, `max_depth` 6 |

### Split 60:40

| model | hyperparameter terbaik |
|---|---|
| XGBoost | `n_estimators` 517, `max_depth` 7, `learning_rate` 0.0025494, `min_child_weight` 21, `subsample` 0.76454, `colsample_bytree` 0.53405, `reg_lambda` 0.029927, `reg_alpha` 0.0058062 |
| LightGBM | `n_estimators` 22, `num_leaves` 4, `max_depth` 7, `learning_rate` 0.010859, `min_child_samples` 57, `subsample` 0.53428, `colsample_bytree` 0.96028, `reg_lambda` 2.15869, `reg_alpha` 0.0016480, `subsample_freq` 1 |
| CatBoost | `iterations` 401, `depth` 8, `learning_rate` 0.0011616, `l2_leaf_reg` 0.16805, `random_strength` 1.75695, `bagging_temperature` 0.88440 |
| AdaBoost | `n_estimators` 79, `learning_rate` 0.019976, `loss` linear, `max_depth` 2 |

---

## 8. Catatan teknis

1. **Reproduksibilitas terkonfirmasi lintas tiga tahap.** Keempat run 80:20 di
   Tahap 3 identik sampai digit terakhir dengan run yang sama di Tahap 1 dan
   Tahap 2 (XGBoost Rp348.261,539456; LightGBM Rp348.157,247281; CatBoost
   Rp348.066,370572; AdaBoost Rp349.047,010432).

2. **XGBoost pada 70:30 menemukan hyperparameter yang sama persis dengan 80:20**
   (`n_estimators` 452, `max_depth` 7, `learning_rate` 0.0031345575861252686, dan
   seterusnya identik sampai semua desimal). Artinya TPE berhenti di titik yang
   sama meskipun data latihnya berbeda 1.008 bar. Model lain tidak menunjukkan hal
   ini — LightGBM, CatBoost, dan AdaBoost menghasilkan hyperparameter berbeda di
   setiap rasio.

3. **Satu run signifikan lebih BURUK daripada Naive pada MAE: AdaBoost 60:40.**
   `MAE_vs_naive_pct` +0,165%, `DM_MAE` **+6,928**, `p_MAE` 4,94e-12. Karena
   `DM_MAE` positif, arah signifikansinya berlawanan dengan yang dicari — Naive
   lebih akurat, dan selisihnya signifikan. Run yang sama justru punya
   `RMSE_vs_naive_pct` -0,085% dengan `DM_RMSE` -4,956 dan `p_RMSE` 7,49e-07.
   `std_pred_return` run ini 3,0e-06, paling kecil di Tahap 3.

4. **`p_RMSE` = 0,0000 pada seluruh 12 run** (nilai terbesar 7,49e-07 pada AdaBoost
   60:40), semuanya dengan `DM_RMSE` negatif. Dicatat sebagai fakta.

5. **Tidak ada run dengan prediksi konstan.** `std_pred_return` berkisar 3,0e-06
   (AdaBoost 60:40) sampai 8,4e-05 (AdaBoost 70:30). Tidak ada nilai nol atau orde
   1e-21 seperti di beberapa run Tahap 1.

6. **Run paling lama**: AdaBoost 70:30 122,2 detik, AdaBoost 80:20 92,2 detik,
   CatBoost 80:20 79,2 detik, AdaBoost 60:40 77,9 detik. LightGBM konsisten
   tercepat di ketiga rasio (4–5 detik).

7. **Waktu total menurun seiring data latih mengecil** (243,2 s pada 80:20 →
   206,1 s pada 70:30 → 185,5 s pada 60:40), konsisten dengan jumlah baris latih
   8.062 → 7.054 → 6.046.

8. **`ringkas.py` menimpa berkas ringkasan.** Sama seperti di Tahap 2, keluaran
   CSV `ringkas.py` ditimpa tiap pemanggilan. Hasil Tahap 3 sudah diarsipkan ke
   `hasil/ringkasan/tahap3/`. Penataan berkas saja; tidak ada perubahan kode.

---

## 9. Berkas yang dihasilkan Tahap 3

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | bertambah 15 baris bertag `tahap3` (12 run model + 3 Naive); total 89 baris |
| `hasil/laporan/LAPORAN_TAHAP3.md` | laporan ini |
| `hasil/laporan/tahap3_ringkasan.txt` | keluaran `ringkas.py --tag tahap3` |
| `hasil/laporan/tahap3_stdout.txt` | keluaran mentah `run.py` |
| `hasil/laporan/tahap3_waktu.txt` | waktu mulai dan selesai |
| `hasil/ringkasan/tahap3/` | arsip 4 CSV ringkasan Tahap 3 |
| `hasil/params/` | bertambah 12 berkas JSON (total 76) |
| `hasil/prediksi/` | bertambah 12 berkas CSV (total 76) |
