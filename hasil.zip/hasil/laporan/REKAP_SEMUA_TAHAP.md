# REKAP SELURUH TAHAP (1–4)

**Eksperimen data satu minggu (14–20 Okt 2026), BTC/IDR Indodax.**
Dibuat 2026-10-28. Bagian 1–6 faktual. Bagian 7 memisahkan dengan tegas mana
keputusan yang keluar dari aturan terkunci dan mana yang masih perlu keputusan Ferdi.

Sumber: `hasil/hasil_semua.csv` (109 baris = 92 run model + 17 baris Naive) dan
laporan per tahap di `hasil/laporan/`.

---

## 1. Apa yang dijalankan

| Tahap | Tujuan | Variasi | Run | Durasi |
|---|---|---|---|---|
| 1 | cari time frame | 2 dataset × 5 horizon × 4 model, `tpe`, 80:20 | 36 | 10 m 46 s |
| 2 | bandingkan metode optimasi | 7 metode × 4 model, `candle_1m` h1, 80:20 | 28 | 17 m 14 s |
| 3 | uji rasio split | 3 split × 4 model, `candle_1m` h1, `tpe` | 12 | 10 m 36 s |
| 4 | teknik tambahan | 4 teknik × 4 model, `candle_1m` h1, `tpe`, 80:20 | 16 | 34 m 46 s |
| **Total** | | | **92** | **73 m 22 s** |

Gagal: **0 dari 92**. Semua exit code 0. Satu kegagalan perintah shell di Tahap 4
(variabel tak terkutip di zsh) tidak menghasilkan baris apa pun dan sudah dijalankan
ulang — rinciannya di `LAPORAN_TAHAP4.md` bagian 3.

Keputusan yang diambil di jalan, semuanya lewat aturan terkunci:
- Tahap 1 → pasangan **`candle_1m`, horizon 1 menit** (Aturan 2)
- Tahap 2 → metode **`tpe`** (rata-rata terkecil, tanpa seri)
- Tahap 3 dan 4 → tidak ada pemilihan

---

## 2. Hasil per tahap

`MAE_vs_naive_pct` negatif = MAE lebih kecil daripada Naive.

| tag | run | rata-rata MAE vs Naive | terbaik MAE vs Naive | rata-rata RMSE vs Naive | rata-rata akurasi arah | total detik |
|---|---|---|---|---|---|---|
| `tahap1` | 36 | +0.2631 | -0.3470 | -0.0997 | 50.347% | 643,6 |
| `tahap2` | 28 | +1.2176 | -0.4890 | -1.4330 | 55.795% | 1.030,6 |
| `tahap3` | 12 | -0.0185 | -0.3470 | -1.8178 | 55.338% | 634,8 |
| `tahap4_earlystop` | 4 | -0.0158 | -0.1031 | -2.1249 | 54.501% | 654,5 |
| `tahap4_topk15` | 4 | +0.1811 | -0.2119 | -1.9591 | 56.400% | 1.113,2 |
| `tahap4_lossl1` | 4 | **-0.2547** | **-0.7232** | -1.2682 | 54.949% | 163,5 |
| `tahap4_prunermedian` | 4 | -0.2271 | -0.3747 | -1.7944 | 56.130% | 148,4 |

Rata-rata `tahap1` dan `tahap2` terangkat oleh run yang buruk: `tahap1` mencakup
semua horizon dan dataset (termasuk yang jauh lebih buruk dari Naive), `tahap2`
mencakup `default` yang rata-ratanya +8,97.

---

## 3. Hasil per tahap, terperinci

### 3a. Tahap 1 — time frame (`MAE_vs_naive_pct`, `tpe`, 80:20)

| dataset | horizon | XGBoost | LightGBM | CatBoost | AdaBoost | skor pasangan |
|---|---|---|---|---|---|---|
| candle_1m | 1 | -0.291 | -0.321 | **-0.347** | -0.066 | **-0.347** |
| candle_1m | 5 | 0.069 | 0.093 | 0.060 | 1.089 | 0.060 |
| candle_1m | 15 | 0.133 | 0.084 | 0.183 | 0.350 | 0.084 |
| candle_1m | 30 | 0.010 | 0.059 | 0.469 | 0.439 | 0.010 |
| candle_1m | 60 | 0.207 | -0.159 | 0.411 | 0.104 | -0.159 |
| ticker_5m | 5 | 0.160 | 0.366 | 1.043 | 0.541 | 0.160 |
| ticker_5m | 15 | 0.269 | 0.132 | 0.792 | 2.554 | 0.132 |
| ticker_5m | 30 | 0.034 | 0.049 | 0.069 | 0.447 | 0.034 |
| ticker_5m | 60 | 0.077 | 0.016 | 0.017 | 0.333 | 0.016 |

### 3b. Tahap 2 — metode optimasi (`candle_1m` h1, 80:20)

| metode | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata | detik tuning |
|---|---|---|---|---|---|---|
| **`tpe`** | -0.291 | -0.321 | -0.347 | -0.066 | **-0.2563** | 229,3 |
| `random` | 0.069 | -0.489 | -0.226 | -0.066 | -0.1780 | 118,7 |
| `qmc` | -0.358 | -0.354 | -0.230 | 0.452 | -0.1225 | 157,4 |
| `ga` | -0.140 | 0.020 | -0.226 | -0.066 | -0.1032 | 140,0 |
| `grid` | 0.059 | -0.041 | -0.301 | 0.420 | 0.0346 | 227,6 |
| `cmaes` | 0.255 | 0.048 | -0.341 | 0.736 | 0.1746 | 129,9 |
| `default` | 4.291 | 6.586 | 10.815 | 14.205 | 8.9741 | 9,2 |

### 3c. Tahap 3 — rasio split (`candle_1m` h1, `tpe`)

| split | n_latih | n_uji | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata |
|---|---|---|---|---|---|---|---|
| **80:20** | 8.062 | 2.016 | -0.291 | -0.321 | -0.347 | -0.066 | **-0.2563** |
| 70:30 | 7.054 | 3.024 | 0.205 | 0.186 | 0.207 | 0.241 | 0.2097 |
| 60:40 | 6.046 | 4.032 | -0.175 | 0.128 | -0.153 | 0.165 | -0.0087 |

MAE rupiah antar-rasio tidak sebanding (periode uji berbeda): Naive 80:20
Rp349.278, 70:30 Rp317.826, 60:40 Rp304.163.

### 3d. Tahap 4 — teknik tambahan (`candle_1m` h1, `tpe`, 80:20)

| teknik | XGBoost | LightGBM | CatBoost | AdaBoost | rata-rata | Δ vs Tahap 2 | detik | Δ waktu |
|---|---|---|---|---|---|---|---|---|
| pembanding (Tahap 2 `tpe`) | -0.291 | -0.321 | -0.347 | -0.066 | -0.2563 | — | 232,6 | — |
| `--loss l1` | 0.232 | **-0.723** | -0.462 | -0.066 | -0.2547 | +0.0016 | 163,5 | **-30%** |
| `--pruner median` | -0.375 | -0.121 | -0.347 | -0.066 | -0.2271 | +0.0292 | 148,4 | **-36%** |
| `--early-stop` | -0.103 | 0.061 | 0.045 | -0.066 | -0.0158 | +0.2405 | 654,5 | +181% |
| `--top-k 15` | 0.315 | -0.212 | 0.392 | 0.230 | +0.1811 | +0.4374 | 1.113,2 | +378% |

---

## 4. Hasil per model, seluruh 92 run

| model | jumlah run | rata-rata MAE vs Naive | terbaik | rata-rata akurasi arah |
|---|---|---|---|---|
| XGBoost | 23 | +0.190 | -0.375 | 54.179% |
| LightGBM | 23 | +0.207 | **-0.723** | 53.612% |
| CatBoost | 23 | +0.486 | -0.462 | 54.017% |
| AdaBoost | 23 | +0.947 | -0.066 | 52.398% |

---

## 5. 15 run terbaik di seluruh eksperimen (urut `MAE_vs_naive_pct`)

Kolom `teknik`: `l1` = `--loss l1`, `ES` = `--early-stop`, `k15` = `--top-k 15`,
`prune` = `--pruner median`, `—` = tanpa teknik tambahan.

| tag | dataset | horizon_menit | split | model | optimasi | teknik | MAE_Rp | MAE_vs_naive_pct | DM_MAE | p_MAE | RMSE_vs_naive_pct | p_RMSE | Akurasi_arah_pct |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| tahap4_lossl1 | candle_1m | 1 | 80:20 | LightGBM | tpe | l1 | 346,752 | -0.723 | -2.133 | 0.0331 | -1.628 | 0.0 | 58.732 |
| tahap2 | candle_1m | 1 | 80:20 | LightGBM | random | — | 347,570 | -0.489 | -0.859 | 0.3902 | -2.779 | 0.0 | 57.117 |
| tahap4_lossl1 | candle_1m | 1 | 80:20 | CatBoost | tpe | l1 | 347,665 | -0.462 | -1.541 | 0.1235 | -1.39 | 0.0 | 57.117 |
| tahap4_prunermedian | candle_1m | 1 | 80:20 | XGBoost | tpe |  prune | 347,969 | -0.375 | -1.221 | 0.2222 | -1.811 | 0.0 | 58.373 |
| tahap2 | candle_1m | 1 | 80:20 | XGBoost | qmc | — | 348,029 | -0.358 | -1.726 | 0.0845 | -1.256 | 0.0 | 57.237 |
| tahap2 | candle_1m | 1 | 80:20 | LightGBM | qmc | — | 348,041 | -0.354 | -1.005 | 0.3148 | -1.849 | 0.0 | 56.28 |
| tahap1 | candle_1m | 1 | 80:20 | CatBoost | tpe | — | 348,066 | -0.347 | -0.85 | 0.3952 | -2.151 | 0.0 | 56.818 |
| tahap2 | candle_1m | 1 | 80:20 | CatBoost | tpe | — | 348,066 | -0.347 | -0.85 | 0.3952 | -2.151 | 0.0 | 56.818 |
| tahap3 | candle_1m | 1 | 80:20 | CatBoost | tpe | — | 348,066 | -0.347 | -0.85 | 0.3952 | -2.151 | 0.0 | 56.818 |
| tahap4_prunermedian | candle_1m | 1 | 80:20 | CatBoost | tpe |  prune | 348,066 | -0.347 | -0.85 | 0.3952 | -2.151 | 0.0 | 56.818 |
| tahap2 | candle_1m | 1 | 80:20 | CatBoost | cmaes | — | 348,088 | -0.341 | -0.935 | 0.3499 | -1.893 | 0.0 | 55.921 |
| tahap1 | candle_1m | 1 | 80:20 | LightGBM | tpe | — | 348,157 | -0.321 | -1.044 | 0.2964 | -1.687 | 0.0 | 56.699 |
| tahap2 | candle_1m | 1 | 80:20 | LightGBM | tpe | — | 348,157 | -0.321 | -1.044 | 0.2964 | -1.687 | 0.0 | 56.699 |
| tahap3 | candle_1m | 1 | 80:20 | LightGBM | tpe | — | 348,157 | -0.321 | -1.044 | 0.2964 | -1.687 | 0.0 | 56.699 |
| tahap2 | candle_1m | 1 | 80:20 | CatBoost | grid | — | 348,228 | -0.301 | -0.95 | 0.3422 | -1.744 | 0.0 | 56.4 |

Baris CatBoost `tpe` yang muncul empat kali (`tahap1`, `tahap2`, `tahap3`,
`tahap4_prunermedian`) dan LightGBM `tpe` tiga kali adalah **run yang sama
dijalankan ulang di tahap berbeda**, bukan empat hasil independen. Angkanya
identik sampai digit terakhir — ini pemeriksaan reproduksibilitas, bukan
pengulangan bukti.

---

## 6. Uji Diebold-Mariano: ringkasan seluruh 92 run

Definisi terkunci: **signifikan lebih baik dari Naive** = `MAE_vs_naive_pct < 0`
**dan** `DM_MAE < 0` **dan** `p_MAE < 0,05`.

| kategori | jumlah run |
|---|---|
| Signifikan lebih baik dari Naive pada MAE | **1** dari 92 |
| Signifikan lebih **buruk** dari Naive pada MAE (`DM_MAE > 0`, `p_MAE < 0,05`) | **17** dari 92 |
| Tidak signifikan ke arah mana pun pada MAE | 74 dari 92 |
| `MAE_vs_naive_pct < 0` (tanpa syarat signifikansi) | 37 dari 92 |
| `RMSE_vs_naive_pct < 0` | 65 dari 92 |
| Akurasi arah > 50% | 71 dari 92 |

### 6a. Satu-satunya run yang signifikan lebih baik dari Naive

| kolom | nilai |
|---|---|
| tag | `tahap4_lossl1` |
| konfigurasi | `candle_1m`, harga `typical`, horizon 1 menit, split 80:20 |
| model | **LightGBM** |
| optimasi | `tpe`, 30 trial, 5 fold |
| teknik | `--loss l1` (objektif MAE), 42 fitur, tanpa early stopping, tanpa pruner |
| MAE | Rp346.752 (Naive Rp349.278) |
| `MAE_vs_naive_pct` | **-0,723186** |
| `DM_MAE` / `p_MAE` | **-2,132559** / **0,033082** |
| `RMSE_vs_naive_pct` | -1,628210 |
| `DM_RMSE` / `p_RMSE` | -5,3245 / 1,13e-07 |
| Akurasi arah | **58,732%** (tertinggi di seluruh eksperimen) |
| `std_pred_return` | 3,66e-05 (prediksi tidak konstan) |
| Hyperparameter | `n_estimators` 38, `num_leaves` 23, `max_depth` 8, `learning_rate` 0,0560859, `min_child_samples` 112, `subsample` 0,942933, `colsample_bytree` 0,874230, `reg_lambda` 0,00690816, `reg_alpha` 0,0127954, `subsample_freq` 1 |

### 6b. Sebaran 17 run yang signifikan lebih buruk dari Naive

| asal | jumlah | contoh terburuk |
|---|---|---|
| `tahap2` `default` (4 model) | 4 | AdaBoost `DM_MAE` +13,533; `MAE_vs_naive_pct` +14,205 |
| `tahap2` AdaBoost (`grid`, `cmaes`, `qmc`) | 3 | `qmc` `DM_MAE` +7,706 |
| `tahap1` (horizon 5–15 mnt, kedua dataset) | 6 | AdaBoost candle h5 `DM_MAE` +2,147 |
| `tahap3` AdaBoost 60:40 | 1 | `DM_MAE` +6,928; `p_MAE` 4,94e-12 |
| `tahap4` (earlystop LightGBM, topk15 AdaBoost, lossl1 XGBoost) | 3 | lossl1 XGBoost `DM_MAE` +13,867 |

### 6c. Run berprediksi konstan atau hampir konstan (`std_pred_return` < 1e-10)

Delapan run. Enam di Tahap 1 (LightGBM candle h5 / h30, LightGBM ticker h60,
XGBoost ticker h30, AdaBoost candle h15 / h60 — dua terakhir `std_pred_return`
nol persis), dan dua di Tahap 4 (`--early-stop` LightGBM 1,06e-22; `--loss l1`
XGBoost 1,14e-13). Akurasi arahnya 47,9%–50,7%, yaitu setara menebak.

---

## 7. Keputusan

### 7a. Yang sudah ditetapkan aturan terkunci (bukan pilihan bebas)

| | pilihan | dasar |
|---|---|---|
| Time frame | `candle_1m`, horizon **1 menit** | Tahap 1, Aturan 2: skor pasangan terkecil (-0,347); tidak seri |
| Metode optimasi | **`tpe`** | Tahap 2: rata-rata 4 model terkecil (-0,2563); `default` terlarang; tidak seri |
| Rasio split | tidak dipilih — ketiganya dilaporkan | Tahap 3 tidak punya aturan pemilihan |
| Teknik tambahan | tidak dipilih — selisih dilaporkan | Tahap 4 tidak punya aturan pemilihan |

### 7b. Konfigurasi terbaik menurut metrik utama yang dikunci

Metrik utama yang dikunci adalah `MAE_vs_naive_pct`, dengan uji DM sebagai syarat
signifikansi. Menerapkan itu ke seluruh 92 run, **tepat satu konfigurasi** memenuhi
definisi "signifikan lebih baik dari Naive":

> **`candle_1m`, horizon 1 menit, split 80:20, LightGBM, `tpe`, `--loss l1`**
> MAE Rp346.752 vs Naive Rp349.278 (**-0,723%**), `DM_MAE` -2,133, `p_MAE` 0,0331,
> akurasi arah 58,732%.

Konfigurasi ini sekaligus yang terbaik pada metrik utama di antara seluruh 92 run,
jadi tidak ada konflik antara "paling baik" dan "satu-satunya yang signifikan".

### 7c. Tiga hal yang masih keputusan Ferdi, bukan keputusan aturan

**1. Apakah temuan 1-dari-92 itu dilaporkan sebagai hasil utama.**
`p_MAE` = 0,0331 adalah satu temuan signifikan dari 92 pengujian pada data dan
periode yang sama. Tanpa koreksi perbandingan ganda, satu p < 0,05 dari 92 uji
adalah yang diharapkan muncul secara kebetulan (ekspektasi ≈ 4,6 run pada α = 0,05
bila tidak ada efek sama sekali). Dengan koreksi Bonferroni (α/92 = 0,000543),
run ini **tidak** signifikan. Ini bukan alasan untuk membuang temuannya, tapi perlu
diputuskan dan ditulis apa adanya di Bab 4 — dan sebaiknya dikonfirmasi ke dosen.

**2. Apakah metrik utama tetap MAE.** Pola yang konsisten di keempat tahap: model
mengalahkan Naive pada **RMSE** secara sangat signifikan (65 dari 92 run
`RMSE_vs_naive_pct` < 0; `p_RMSE` = 0,0000 pada hampir semua run di `candle_1m` h1),
tetapi tidak pada **MAE**. Dokumen terkunci menetapkan MAE sebagai metrik utama
sebelum hasil dilihat, dan **saya tidak menggantinya** — justru itu gunanya dikunci.
Tapi perbedaan arah antara dua metrik ini adalah hasil substantif yang layak
dibahas, bukan disembunyikan.

**3. Status data.** Seluruh angka di atas berlaku untuk **satu minggu
(14–20 Okt 2026)**. Catatan di `KEPUTUSAN_TERKUNCI.md` menyebut status data (satu
minggu vs seluruh data sampai Februari 2027, ±40.000 baris) **belum dipastikan ke
dosen**. Selama itu belum dipastikan, seluruh rekap ini adalah hasil satu minggu
dan tidak boleh ditulis sebagai kesimpulan umum. Mengulang Tahap 1–4 pada rentang
yang lebih panjang akan memakan waktu sekitar 73 menit × (40.000/10.080) ≈ 5 jam
pada perangkat ini — masih sangat terjangkau.

### 7d. Catatan untuk Bab 3 (metodologi), dari hal yang teramati

| temuan | implikasi yang perlu ditulis |
|---|---|
| `random`, `tpe`, `ga` memberi hasil identik pada AdaBoost di Tahap 2; `random` = `ga` pada CatBoost | Perbandingan metode optimasi terbatas karena seed dan trial acak awal sama (README bagian 6 nomor 5) |
| XGBoost 70:30 menemukan hyperparameter identik dengan 80:20 sampai semua desimal | Perilaku konvergensi TPE, layak disebut |
| `grid` memakai 27 trial, lainnya 30 | Jumlah evaluasi antar metode tidak setara |
| 8 run menghasilkan prediksi konstan | Perlu dilaporkan, bukan dibuang: model memilih setelan yang meredam dirinya sampai memprediksi satu nilai |
| AdaBoost tidak terpengaruh `--loss` dan `--early-stop` | README bagian 6 nomor 7; angkanya identik di 3 tag Tahap 4 |
| `--pruner median` memangkas 14 dari 30 trial rata-rata, hemat 36% waktu, rata-rata MAE hanya memburuk 0,029 poin | Teknik paling efisien dari keempatnya |
| `--top-k 15` justru 4,8× lebih lambat meski fitur turun 42 → 15 | Berlawanan dengan dugaan umum soal seleksi fitur |

---

## 8. Peta berkas

| Berkas | Isi |
|---|---|
| `hasil/hasil_semua.csv` | 109 baris, semua run + Naive, 39 kolom |
| `hasil/laporan/LAPORAN_TAHAP1.md` … `LAPORAN_TAHAP4.md` | laporan faktual per tahap |
| `hasil/laporan/REKAP_SEMUA_TAHAP.md` | berkas ini |
| `hasil/laporan/tahap*_ringkasan.txt` | keluaran `ringkas.py` per tag (7 berkas) |
| `hasil/laporan/tahap*_stdout.txt` | keluaran mentah `run.py` (7 berkas) |
| `hasil/laporan/tahap*_waktu.txt` | waktu mulai/selesai (4 berkas) |
| `hasil/metadata/` | versi paket, hash + rentang data, salinan `config.py`, spesifikasi perangkat |
| `hasil/KEPUTUSAN_TERKUNCI.md` | desain dan aturan pemilihan, dikunci 27 Okt 2026 10:08:33 WIB |
| `hasil/LOG_PERUBAHAN.md` | semua perubahan kode dan environment |
| `hasil/params/` | 92 JSON: hyperparameter terbaik + daftar fitur per run |
| `hasil/prediksi/` | 92 CSV: prediksi data uji per run |
| `hasil/ringkasan/tahap*/` | arsip CSV ringkasan per tahap (7 folder) |
